-- =============================================================================
-- verify_schema.sql — structural assertions for Ecommerce schema v3
-- Usage: psql -v ON_ERROR_STOP=1 -d <db> -f tests/verify_schema.sql
-- Fails (RAISE EXCEPTION) if counts do not match the design: 70 tables, 173 FKs (v3 + authz 2026-10-04),
-- every table has a PK, every FK column is the leading column of some index,
-- audit standard: every table has exactly created_date_time / created_by / modified_date_time / modified_by
--   with the right type/nullability/default, no FK on them, no created_at/updated_at/updated_by column anywhere,
--   every table has trg_<table>_modified_date_time -> set_modified_date_time(); session timezone Asia/Bangkok.
-- Optional: -v audit_order=strict also requires the 4 audit columns to be the LAST 4 columns in that order
--   (true for clean installs; Flyway-migrated V1/V2 tables keep renamed columns in their original position).
-- =============================================================================
\pset footer off
\if :{?audit_order}
SELECT set_config('verify.audit_order', :'audit_order', false) AS audit_order_mode;
\else
SELECT set_config('verify.audit_order', 'lenient', false) AS audit_order_mode;
\endif
SHOW timezone;
SELECT now() AS now_bangkok, to_char(now(), 'OF') AS utc_offset;
SELECT
  (SELECT count(*) FROM information_schema.tables
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE' AND table_name <> 'flyway_schema_history') AS tables,
  (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
    WHERE n.nspname = 'public' AND c.contype = 'f') AS foreign_keys,
  (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
    WHERE n.nspname = 'public' AND c.contype = 'p') AS primary_keys,
  (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
    WHERE n.nspname = 'public' AND c.contype = 'u') AS unique_constraints,
  (SELECT count(*) FROM pg_indexes WHERE schemaname = 'public' AND indexname LIKE 'uq\_%' AND indexdef LIKE '% WHERE %') AS partial_unique_idx,
  (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
    WHERE n.nspname = 'public' AND c.contype = 'c') AS check_constraints,
  (SELECT count(*) FROM pg_indexes WHERE schemaname = 'public') AS indexes_total,
  (SELECT count(*) FROM pg_trigger t JOIN pg_class r ON r.oid = t.tgrelid JOIN pg_namespace n ON n.oid = r.relnamespace
    WHERE n.nspname = 'public' AND NOT t.tgisinternal) AS triggers,
  (SELECT count(*) FROM pg_description d JOIN pg_class r ON r.oid = d.objoid AND d.classoid = 'pg_class'::regclass
    JOIN pg_namespace n ON n.oid = r.relnamespace WHERE n.nspname = 'public' AND d.objsubid = 0 AND r.relkind = 'r') AS table_comments,
  (SELECT count(*) FROM pg_description d JOIN pg_class r ON r.oid = d.objoid AND d.classoid = 'pg_class'::regclass
    JOIN pg_namespace n ON n.oid = r.relnamespace WHERE n.nspname = 'public' AND d.objsubid > 0) AS column_comments;

DO $$
DECLARE
  n_tables int; n_fk int; n_nopk int; n_fk_noidx int; n_badname int; n_trg_missing int; rec record;
  n_audit_bad int; n_forbidden int; n_audit_fk int; n_order_bad int; n_audit_cols int; tz text;
BEGIN
  SELECT count(*) INTO n_tables FROM information_schema.tables
   WHERE table_schema = 'public' AND table_type = 'BASE TABLE' AND table_name <> 'flyway_schema_history';
  SELECT count(*) INTO n_fk FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
   WHERE n.nspname = 'public' AND c.contype = 'f';
  SELECT count(*) INTO n_nopk FROM pg_class r JOIN pg_namespace n ON n.oid = r.relnamespace
   WHERE n.nspname = 'public' AND r.relkind = 'r' AND r.relname <> 'flyway_schema_history'
     AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.conrelid = r.oid AND c.contype = 'p');
  -- FK (single column) without an index whose first key column is that column
  SELECT count(*) INTO n_fk_noidx FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
   WHERE n.nspname = 'public' AND c.contype = 'f'
     AND NOT EXISTS (SELECT 1 FROM pg_index i WHERE i.indrelid = c.conrelid AND i.indkey[0] = c.conkey[1]);
  -- naming convention
  SELECT count(*) INTO n_badname FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
   JOIN pg_class r ON r.oid = c.conrelid
   WHERE n.nspname = 'public' AND r.relname <> 'flyway_schema_history' AND NOT (
         (c.contype = 'p' AND c.conname = 'pk_' || r.relname)
      OR (c.contype = 'f' AND c.conname LIKE 'fk\_' || r.relname || '\_%')
      OR (c.contype = 'u' AND c.conname LIKE 'uq\_' || r.relname || '\_%')
      OR (c.contype = 'c' AND c.conname LIKE 'ck\_' || r.relname || '\_%')
      OR (c.contype = 't' AND c.conname LIKE 'trg\_' || r.relname || '\_%'));   -- authz constraint triggers
  -- audit standard ------------------------------------------------------------------------------
  -- (a) each base table has each of the 4 audit columns exactly once with the expected definition
  SELECT count(*) INTO n_audit_cols FROM information_schema.columns c
   JOIN information_schema.tables t ON t.table_schema = c.table_schema AND t.table_name = c.table_name AND t.table_type = 'BASE TABLE'
   WHERE c.table_schema = 'public' AND c.table_name <> 'flyway_schema_history'
     AND c.column_name IN ('created_date_time','created_by','modified_date_time','modified_by');
  SELECT count(*) INTO n_audit_bad FROM (
    SELECT t.table_name, a.col, a.typ, a.nul, a.dflt
      FROM information_schema.tables t
      CROSS JOIN (VALUES ('created_date_time','timestamp with time zone','NO','now()'),
                         ('created_by','uuid','YES',NULL),
                         ('modified_date_time','timestamp with time zone','NO','now()'),
                         ('modified_by','uuid','YES',NULL)) AS a(col, typ, nul, dflt)
     WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE' AND t.table_name <> 'flyway_schema_history'
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns c
                        WHERE c.table_schema = 'public' AND c.table_name = t.table_name AND c.column_name = a.col
                          AND c.data_type = a.typ AND c.is_nullable = a.nul
                          AND c.column_default IS NOT DISTINCT FROM a.dflt)) x;
  FOR rec IN SELECT t.table_name, a.col
      FROM information_schema.tables t
      CROSS JOIN (VALUES ('created_date_time','timestamp with time zone','NO','now()'), ('created_by','uuid','YES',NULL),
                         ('modified_date_time','timestamp with time zone','NO','now()'), ('modified_by','uuid','YES',NULL)) AS a(col, typ, nul, dflt)
     WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE' AND t.table_name <> 'flyway_schema_history'
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns c
                        WHERE c.table_schema = 'public' AND c.table_name = t.table_name AND c.column_name = a.col
                          AND c.data_type = a.typ AND c.is_nullable = a.nul AND c.column_default IS NOT DISTINCT FROM a.dflt) LOOP
    RAISE WARNING 'audit column missing/wrong: %.%', rec.table_name, rec.col;
  END LOOP;
  -- (b) legacy names must not exist anywhere in the schema
  SELECT count(*) INTO n_forbidden FROM information_schema.columns
   WHERE table_schema = 'public' AND column_name IN ('created_at','updated_at','updated_by');
  -- (c) no FK on audit columns (logical ref users.id only)
  SELECT count(*) INTO n_audit_fk FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
   JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY (c.conkey)
   WHERE n.nspname = 'public' AND c.contype = 'f' AND a.attname IN ('created_by','modified_by');
  -- (d) every table has the modified_date_time trigger calling set_modified_date_time()
  SELECT count(*) INTO n_trg_missing FROM information_schema.tables tb
   WHERE tb.table_schema = 'public' AND tb.table_type = 'BASE TABLE' AND tb.table_name <> 'flyway_schema_history'
     AND NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_proc p ON p.oid = t.tgfoid
                      WHERE t.tgrelid = (quote_ident(tb.table_name))::regclass
                        AND t.tgname = 'trg_' || tb.table_name || '_modified_date_time'
                        AND p.proname = 'set_modified_date_time' AND NOT t.tgisinternal
                        AND (t.tgtype & 2) = 2 AND (t.tgtype & 16) = 16);   -- BEFORE + UPDATE
  -- (e) order: last 4 columns = created_date_time, created_by, modified_date_time, modified_by
  SELECT count(*) INTO n_order_bad FROM (
    SELECT table_name, string_agg(column_name, ',' ORDER BY ordinal_position) AS last4
      FROM (SELECT c.table_name, c.column_name, c.ordinal_position,
                   row_number() OVER (PARTITION BY c.table_name ORDER BY c.ordinal_position DESC) AS rn
              FROM information_schema.columns c
              JOIN information_schema.tables t ON t.table_schema = c.table_schema AND t.table_name = c.table_name AND t.table_type = 'BASE TABLE'
             WHERE c.table_schema = 'public' AND c.table_name <> 'flyway_schema_history') z
     WHERE rn <= 4 GROUP BY table_name) y
   WHERE last4 <> 'created_date_time,created_by,modified_date_time,modified_by';
  tz := current_setting('TimeZone');
  FOR rec IN SELECT c.conname FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace
            WHERE n.nspname = 'public' AND c.contype = 'f'
              AND NOT EXISTS (SELECT 1 FROM pg_index i WHERE i.indrelid = c.conrelid AND i.indkey[0] = c.conkey[1]) LOOP
    RAISE WARNING 'FK without index: %', rec.conname;
  END LOOP;
  RAISE NOTICE 'tables=% fks=% tables_without_pk=% fk_without_index=% bad_constraint_names=% missing_modified_triggers=%',
               n_tables, n_fk, n_nopk, n_fk_noidx, n_badname, n_trg_missing;
  RAISE NOTICE 'audit: audit_columns=% (expect %) wrong_or_missing=% legacy_created_at/updated_at/updated_by=% audit_fks=% tables_not_ending_with_audit4=% (mode %) timezone=%',
               n_audit_cols, n_tables * 4, n_audit_bad, n_forbidden, n_audit_fk, n_order_bad, current_setting('verify.audit_order'), tz;
  IF n_tables <> 70 THEN RAISE EXCEPTION 'expected 70 tables, got %', n_tables; END IF;
  IF n_fk <> 173 THEN RAISE EXCEPTION 'expected 173 foreign keys, got %', n_fk; END IF;
  -- authz: constraint triggers (deferred) + partial unique indexes + CHECKs
  IF (SELECT count(*) FROM pg_trigger t WHERE t.tgname IN ('trg_shop_members_owner_guard', 'trg_shops_owner_guard')
        AND t.tgconstraint <> 0 AND t.tgdeferrable AND t.tginitdeferred) <> 2 THEN
    RAISE EXCEPTION 'authz owner-guard constraint triggers missing or not DEFERRABLE INITIALLY DEFERRED'; END IF;
  IF (SELECT count(*) FROM pg_indexes WHERE schemaname = 'public' AND indexname IN ('uq_platform_roles_user_id_active',
        'uq_merchant_applications_user_id_open', 'uq_shop_members_shop_id_owner', 'uq_shop_invitations_shop_id_email_pending',
        'uq_shop_customers_shop_id_user_id', 'uq_shop_ownership_transfers_shop_id_pending')) <> 6 THEN
    RAISE EXCEPTION 'authz partial unique indexes missing'; END IF;
  IF (SELECT count(*) FROM pg_constraint WHERE conname IN ('ck_merchant_applications_reviewer_not_applicant',
        'ck_shop_ownership_transfers_parties', 'ck_inventory_ledger_adjust_reason', 'ck_audit_logs_service_name',
        'ck_auth_roles_code_format', 'ck_auth_permissions_code_format', 'ck_refunds_amount')) <> 7 THEN
    RAISE EXCEPTION 'authz CHECK constraints missing'; END IF;
  IF n_nopk <> 0 THEN RAISE EXCEPTION '% table(s) without primary key', n_nopk; END IF;
  IF n_fk_noidx <> 0 THEN RAISE EXCEPTION '% FK column(s) without index', n_fk_noidx; END IF;
  IF n_badname <> 0 THEN RAISE EXCEPTION '% constraint(s) violate naming convention', n_badname; END IF;
  IF n_trg_missing <> 0 THEN RAISE EXCEPTION '% table(s) without trg_<table>_modified_date_time', n_trg_missing; END IF;
  IF n_audit_cols <> n_tables * 4 THEN RAISE EXCEPTION 'expected % audit columns, got %', n_tables * 4, n_audit_cols; END IF;
  IF n_audit_bad <> 0 THEN RAISE EXCEPTION '% audit column(s) missing or with wrong type/nullability/default', n_audit_bad; END IF;
  IF n_forbidden <> 0 THEN RAISE EXCEPTION '% legacy created_at/updated_at/updated_by column(s) remain', n_forbidden; END IF;
  IF n_audit_fk <> 0 THEN RAISE EXCEPTION '% FK(s) on created_by/modified_by (must be logical refs only)', n_audit_fk; END IF;
  IF n_order_bad <> 0 THEN
    IF current_setting('verify.audit_order') = 'strict' THEN
      RAISE EXCEPTION '% table(s) do not end with the 4 audit columns in order', n_order_bad;
    ELSE
      RAISE NOTICE '% table(s) do not end with the audit columns (expected only for Flyway-renamed V1/V2 tables)', n_order_bad;
    END IF;
  END IF;
  IF tz <> 'Asia/Bangkok' THEN RAISE EXCEPTION 'session TimeZone is %, expected Asia/Bangkok (ALTER DATABASE ... SET timezone not applied?)', tz; END IF;
  RAISE NOTICE 'verify_schema: ALL CHECKS PASSED';
END $$;
