-- =============================================================================
-- smoke_test.sql — happy-path row chain + negative constraint checks (10 core + 15 authz + transfer), then ROLLBACK
-- user -> shop -> product -> sku -> inventory_level -> cart/checkout -> order -> order_item
--      -> reservation -> payment -> payment_proof -> merchant confirm -> shipment -> tracking
-- Usage: psql -v ON_ERROR_STOP=1 -d <db> -f tests/smoke_test.sql   (leaves NO data behind)
-- =============================================================================
BEGIN;

INSERT INTO users (id, first_name, last_name, email, phone, password_hash)
VALUES ('00000000-0000-0000-0000-000000000001', 'Somchai', 'Buyer',  'buyer@example.test',  '0800000001', 'x'),
       ('00000000-0000-0000-0000-000000000002', 'Suda',    'Seller', 'seller@example.test', '0800000002', 'x');

INSERT INTO shops (id, slug, name, owner_user_id)
VALUES ('00000000-0000-0000-0000-0000000000a1', 'smoke-shop', 'Smoke Shop', '00000000-0000-0000-0000-000000000002');
INSERT INTO shop_members (shop_id, user_id, role)
VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000002', 'STORE_OWNER');
INSERT INTO shop_payment_gateways (id, shop_id, provider, display_name, is_active)
VALUES ('00000000-0000-0000-0000-0000000000a2', '00000000-0000-0000-0000-0000000000a1', 'PROMPTPAY', 'PromptPay', true);

INSERT INTO products (id, shop_id, slug, name, status, base_price)
VALUES ('00000000-0000-0000-0000-0000000000b1', '00000000-0000-0000-0000-0000000000a1', 'tee', 'T-Shirt', 'PUBLISHED', 199.00);
INSERT INTO product_skus (id, product_id, shop_id, sku_code, price, option_label)
VALUES ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-0000000000b1',
        '00000000-0000-0000-0000-0000000000a1', 'TEE-RED-M', 199.00, 'สี:แดง / ไซส์:M');
INSERT INTO inventory_levels (shop_id, sku_id, on_hand, reserved_qty, available)
VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2', 10, 0, 10);

INSERT INTO buyer_addresses (id, buyer_user_id, recipient_name, phone, address_line1, district, province, postal_code)
VALUES ('00000000-0000-0000-0000-0000000000c0', '00000000-0000-0000-0000-000000000001', 'Somchai', '0800000001',
        '1 ถ.สุขุมวิท', 'วัฒนา', 'กรุงเทพมหานคร', '10110');
INSERT INTO carts (id, buyer_user_id, shop_id)
VALUES ('00000000-0000-0000-0000-0000000000c1', '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000a1');
INSERT INTO cart_items (cart_id, sku_id, product_id, quantity, unit_price_snapshot)
VALUES ('00000000-0000-0000-0000-0000000000c1', '00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-0000000000b1', 2, 199.00);
INSERT INTO checkouts (id, buyer_user_id, shop_id, cart_id, idempotency_key, shipping_address_id, subtotal, grand_total)
VALUES ('00000000-0000-0000-0000-0000000000c2', '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000a1',
        '00000000-0000-0000-0000-0000000000c1', 'chk-smoke-1', '00000000-0000-0000-0000-0000000000c0', 398.00, 398.00);

INSERT INTO orders (id, shop_id, order_number, buyer_user_id, subtotal, grand_total, idempotency_key, placed_at, merchant_confirm_status)
VALUES ('00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1', 'SO-0001',
        '00000000-0000-0000-0000-000000000001', 398.00, 398.00, 'chk-smoke-1', now(), 'AWAITING');
UPDATE checkouts SET order_id = '00000000-0000-0000-0000-0000000000d1', status = 'COMPLETED'
 WHERE id = '00000000-0000-0000-0000-0000000000c2';
UPDATE carts SET status = 'CONVERTED' WHERE id = '00000000-0000-0000-0000-0000000000c1';
INSERT INTO order_items (id, order_id, shop_id, product_id, sku_id, sku_code_snapshot, product_name_snapshot,
                         unit_price, quantity, line_total)
VALUES ('00000000-0000-0000-0000-0000000000d2', '00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1',
        '00000000-0000-0000-0000-0000000000b1', '00000000-0000-0000-0000-0000000000b2', 'TEE-RED-M', 'T-Shirt', 199.00, 2, 398.00);
INSERT INTO order_addresses (order_id, address_type, recipient_name, phone, address_line1, district, province, postal_code)
VALUES ('00000000-0000-0000-0000-0000000000d1', 'SHIPPING', 'Somchai', '0800000001', '1 ถ.สุขุมวิท', 'วัฒนา', 'กรุงเทพมหานคร', '10110');
INSERT INTO order_financial_snapshots (order_id, shop_id, subtotal, grand_total, item_count, total_qty, buyer_province_hint)
VALUES ('00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1', 398.00, 398.00, 1, 2, 'กรุงเทพมหานคร');
INSERT INTO order_status_history (order_id, to_status, changed_by_type)
VALUES ('00000000-0000-0000-0000-0000000000d1', 'PENDING_PAYMENT', 'SYSTEM');

INSERT INTO inventory_reservations (id, shop_id, sku_id, checkout_id, order_id, order_item_id, quantity)
VALUES ('00000000-0000-0000-0000-0000000000e1', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2',
        '00000000-0000-0000-0000-0000000000c2', '00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000d2', 2);
UPDATE inventory_levels SET reserved_qty = 2, available = 8 WHERE sku_id = '00000000-0000-0000-0000-0000000000b2';
INSERT INTO inventory_ledger (shop_id, sku_id, entry_type, quantity_delta, on_hand_before, on_hand_after,
                              reserved_qty_before, reserved_qty_after, reservation_id, order_item_id, idempotency_key, actor_type)
VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2', 'RESERVE', 0, 10, 10, 0, 2,
        '00000000-0000-0000-0000-0000000000e1', '00000000-0000-0000-0000-0000000000d2', 'res-smoke-1', 'SYSTEM');

INSERT INTO payments (id, order_id, shop_id, gateway_id, provider, amount, idempotency_key, status)
VALUES ('00000000-0000-0000-0000-0000000000f1', '00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1',
        '00000000-0000-0000-0000-0000000000a2', 'PROMPTPAY', 398.00, 'pay-smoke-1', 'PENDING');
INSERT INTO media_files (id, shop_id, uploader_id, purpose, storage_key, original_filename, content_type, file_size)
VALUES ('00000000-0000-0000-0000-0000000000f2', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000001',
        'PAYMENT_SLIP', 'slips/smoke.jpg', 'slip.jpg', 'image/jpeg', 12345);
INSERT INTO payment_proofs (payment_id, order_id, shop_id, uploaded_by_user_id, media_file_id, amount_declared)
VALUES ('00000000-0000-0000-0000-0000000000f1', '00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1',
        '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000f2', 398.00);

-- audit standard: modified_date_time trigger — force an old value, then UPDATE must reset it to now()
UPDATE payments SET modified_date_time = '2000-01-01' WHERE id = '00000000-0000-0000-0000-0000000000f1';
UPDATE payments SET status = 'CAPTURED', captured_at = now(), paid_at = now(),
                    modified_by = '00000000-0000-0000-0000-000000000002'
 WHERE id = '00000000-0000-0000-0000-0000000000f1';
DO $$ BEGIN
  IF (SELECT modified_date_time FROM payments WHERE id = '00000000-0000-0000-0000-0000000000f1') <> now() THEN
    RAISE EXCEPTION 'modified_date_time trigger did not fire on payments';
  END IF;
  IF (SELECT modified_by FROM payments WHERE id = '00000000-0000-0000-0000-0000000000f1') <> '00000000-0000-0000-0000-000000000002' THEN
    RAISE EXCEPTION 'modified_by not stored';
  END IF;
END $$;
-- append-only table (had no "modified" column before the audit standard): insert defaults created = modified; trigger also fires on UPDATE
UPDATE inventory_ledger SET modified_date_time = '2000-01-01' WHERE idempotency_key = 'res-smoke-1';
UPDATE inventory_ledger SET actor_type = actor_type WHERE idempotency_key = 'res-smoke-1';
DO $$ BEGIN
  IF (SELECT modified_date_time FROM inventory_ledger WHERE idempotency_key = 'res-smoke-1') <> now() THEN
    RAISE EXCEPTION 'modified_date_time trigger did not fire on inventory_ledger';
  END IF;
  IF EXISTS (SELECT 1 FROM order_status_history WHERE created_date_time <> modified_date_time) THEN
    RAISE EXCEPTION 'append-only insert: modified_date_time should equal created_date_time';
  END IF;
END $$;
-- created_by / modified_by are logical refs (no FK): any UUID or NULL (system) is accepted
INSERT INTO audit_logs (actor_type, action, resource_type, outcome, created_by)
VALUES ('SYSTEM', 'SMOKE_TEST', 'order', 'SUCCESS', '00000000-0000-0000-0000-00000000beef');
-- Thai timezone: session/database TimeZone = Asia/Bangkok -> timestamps render with +07
DO $$ BEGIN
  IF current_setting('TimeZone') <> 'Asia/Bangkok' THEN RAISE EXCEPTION 'TimeZone is %', current_setting('TimeZone'); END IF;
  IF to_char((SELECT created_date_time FROM payments WHERE id = '00000000-0000-0000-0000-0000000000f1'), 'OF') <> '+07' THEN
    RAISE EXCEPTION 'created_date_time does not render as +07';
  END IF;
END $$;
SELECT current_setting('TimeZone') AS timezone, created_date_time, modified_date_time, created_date_time::text AS rendered
  FROM payments WHERE id = '00000000-0000-0000-0000-0000000000f1';
UPDATE orders SET status = 'PAID_AWAITING_MERCHANT_CONFIRM', payment_status = 'PAID', paid_at = now()
 WHERE id = '00000000-0000-0000-0000-0000000000d1';
UPDATE inventory_reservations SET status = 'PAID_HOLD', paid_hold_at = now() WHERE id = '00000000-0000-0000-0000-0000000000e1';
INSERT INTO merchant_order_confirmations (order_id, shop_id, confirmed_by_user_id)
VALUES ('00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000002');
UPDATE orders SET status = 'MERCHANT_CONFIRMED', merchant_confirm_status = 'CONFIRMED',
                  merchant_confirmed_at = now(), items_revealed_at = now()
 WHERE id = '00000000-0000-0000-0000-0000000000d1';
INSERT INTO shipments (id, order_id, shop_id, carrier_code, tracking_number)
VALUES ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-0000000000d1',
        '00000000-0000-0000-0000-0000000000a1', 'KERRY', 'KER123');
INSERT INTO shipment_items (shipment_id, order_item_id, quantity)
VALUES ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-0000000000d2', 2);
INSERT INTO shipment_tracking_events (shipment_id, shop_id, source, normalized_status, event_at, external_event_id)
VALUES ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-0000000000a1', 'CARRIER_WEBHOOK', 'IN_TRANSIT', now(), 'evt-1'),
       ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-0000000000a1', 'SYSTEM', 'DISPATCHED', now(), NULL),
       ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-0000000000a1', 'SYSTEM', 'DISPATCHED', now(), NULL);
UPDATE orders SET status = 'COMPLETED', completed_at = now(), completion_source = 'BUYER_CONFIRM', buyer_received_at = now()
 WHERE id = '00000000-0000-0000-0000-0000000000d1';

-- ---------------------------------------------------------------- negative checks (each must FAIL)
DO $$
DECLARE ok int := 0;
BEGIN
  BEGIN UPDATE orders SET status = 'SHIPPED' WHERE id = '00000000-0000-0000-0000-0000000000d1';
        RAISE EXCEPTION 'CHECK orders.status not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO payments (order_id, shop_id, provider, amount, idempotency_key)
        VALUES ('00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1', 'COD', 1, 'pay-cod');
        RAISE EXCEPTION 'CHECK payments.provider not enforced (COD must be rejected)';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN UPDATE order_items SET quantity = 0 WHERE id = '00000000-0000-0000-0000-0000000000d2';
        RAISE EXCEPTION 'CHECK order_items.quantity > 0 not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO product_skus (product_id, shop_id, sku_code, price)
        VALUES ('00000000-0000-0000-0000-0000000000b1', '00000000-0000-0000-0000-0000000000a1', 'TEE-RED-M', 1);
        RAISE EXCEPTION 'UNIQUE(shop_id, sku_code) not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO shipment_tracking_events (shipment_id, shop_id, source, normalized_status, event_at, external_event_id)
        VALUES ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-0000000000a1', 'OMS', 'DELIVERED', now(), 'evt-1');
        RAISE EXCEPTION 'UNIQUE(shipment_id, external_event_id) not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO carts (buyer_user_id, shop_id, status)
        VALUES ('00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000a1', 'ACTIVE');
        INSERT INTO carts (buyer_user_id, shop_id, status)
        VALUES ('00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-0000000000a1', 'ACTIVE');
        RAISE EXCEPTION 'partial UNIQUE carts(buyer_user_id, shop_id) WHERE ACTIVE not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO order_items (order_id, shop_id, sku_code_snapshot, product_name_snapshot, unit_price, quantity, line_total)
        VALUES ('00000000-0000-0000-0000-00000000dead', '00000000-0000-0000-0000-0000000000a1', 'X', 'X', 1, 1, 1);
        RAISE EXCEPTION 'FK order_items.order_id not enforced';
  EXCEPTION WHEN foreign_key_violation THEN ok := ok + 1; END;
  BEGIN DELETE FROM shops WHERE id = '00000000-0000-0000-0000-0000000000a1';
        RAISE EXCEPTION 'ON DELETE RESTRICT orders.shop_id not enforced';
  EXCEPTION WHEN foreign_key_violation OR restrict_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO shop_invitations (shop_id, email, role, token_hash, invited_by, expires_at)
        VALUES ('00000000-0000-0000-0000-0000000000a1', 'x@example.test', 'STORE_OWNER', 'h1',
                '00000000-0000-0000-0000-000000000002', now() + interval '1 day');
        RAISE EXCEPTION 'CHECK shop_invitations.role <> STORE_OWNER not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO product_reviews (shop_id, product_id, buyer_user_id, rating)
        VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b1', '00000000-0000-0000-0000-000000000001', 6);
        RAISE EXCEPTION 'CHECK product_reviews.rating BETWEEN 1 AND 5 not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  RAISE NOTICE 'smoke_test: happy path OK, % / 10 negative constraint checks rejected as expected', ok;
  IF ok <> 10 THEN RAISE EXCEPTION 'core negatives: only % / 10', ok; END IF;
END $$;

-- ---------------------------------------------------------------- authz (2026-10-04): Role and Permission Matrix guarantees
INSERT INTO users (id, first_name, last_name, email, phone, password_hash)
VALUES ('00000000-0000-0000-0000-000000000003', 'Mana',  'Staff', 'staff@example.test', '0800000003', 'x'),
       ('00000000-0000-0000-0000-000000000004', 'Piti',  'Admin', 'padmin@example.test', '0800000004', 'x');
INSERT INTO shop_members (id, shop_id, user_id, role)
VALUES ('00000000-0000-0000-0000-000000000203', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000003', 'STORE_ADMIN');
-- application: one open per user; closed → may apply again; review history
INSERT INTO merchant_applications (id, user_id, status) VALUES ('00000000-0000-0000-0000-000000000301', '00000000-0000-0000-0000-000000000001', 'SUBMITTED');
INSERT INTO merchant_application_reviews (application_id, reviewer_id, action, from_status, to_status, reason_code)
VALUES ('00000000-0000-0000-0000-000000000301', '00000000-0000-0000-0000-000000000004', 'REJECT', 'SUBMITTED', 'REJECTED', 'DOC_INVALID');
UPDATE merchant_applications SET status = 'REJECTED', reviewer_id = '00000000-0000-0000-0000-000000000004', reviewed_at = now()
 WHERE id = '00000000-0000-0000-0000-000000000301';
INSERT INTO merchant_applications (id, user_id, status) VALUES ('00000000-0000-0000-0000-000000000302', '00000000-0000-0000-0000-000000000001', 'DRAFT');
-- platform role: grant, revoke, re-grant (history kept)
INSERT INTO platform_roles (user_id, role, grant_reason) VALUES ('00000000-0000-0000-0000-000000000004', 'PLATFORM_ADMIN', 'smoke');
UPDATE platform_roles SET revoked_at = now(), revoked_by = '00000000-0000-0000-0000-000000000004', revoke_reason = 'smoke'
 WHERE user_id = '00000000-0000-0000-0000-000000000004';
INSERT INTO platform_roles (user_id, role, grant_reason) VALUES ('00000000-0000-0000-0000-000000000004', 'PLATFORM_ADMIN', 'smoke re-grant');
-- shop customer + manual order link
INSERT INTO shop_customers (id, shop_id, user_id, customer_code, display_name, phone, source)
VALUES ('00000000-0000-0000-0000-000000000401', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000001', 'C001', 'Somchai', '0800000001', 'STOREFRONT');
UPDATE orders SET shop_customer_id = '00000000-0000-0000-0000-000000000401', row_version = row_version + 1
 WHERE id = '00000000-0000-0000-0000-0000000000d1';
INSERT INTO shop_invitations (shop_id, email, role, token_hash, invited_by, expires_at)
VALUES ('00000000-0000-0000-0000-0000000000a1', 'New.Staff@example.test', 'STORE_SALES', 'inv-h1', '00000000-0000-0000-0000-000000000002', now() + interval '1 day');
-- owner guard passes for the happy-path shop (shop + owner member inserted in the same transaction)
SET CONSTRAINTS trg_shops_owner_guard, trg_shop_members_owner_guard IMMEDIATE;
SET CONSTRAINTS ALL DEFERRED;

DO $$
DECLARE ok int := 0;
BEGIN
  BEGIN INSERT INTO merchant_applications (user_id, status) VALUES ('00000000-0000-0000-0000-000000000001', 'SUBMITTED');
        RAISE EXCEPTION 'partial UNIQUE merchant_applications(user_id) WHERE open not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN UPDATE merchant_applications SET reviewer_id = user_id WHERE id = '00000000-0000-0000-0000-000000000302';
        RAISE EXCEPTION 'CHECK reviewer_id <> user_id (self-review) not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO shop_members (shop_id, user_id, role) VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000004', 'STORE_OWNER');
        RAISE EXCEPTION 'partial UNIQUE one ACTIVE STORE_OWNER per shop not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN UPDATE shop_members SET status = 'INACTIVE', removed_at = now()
         WHERE shop_id = '00000000-0000-0000-0000-0000000000a1' AND role = 'STORE_OWNER';
        SET CONSTRAINTS trg_shop_members_owner_guard IMMEDIATE;
        RAISE EXCEPTION 'owner guard: deactivating the only owner not rejected';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  SET CONSTRAINTS ALL DEFERRED;
  BEGIN INSERT INTO shops (id, slug, name, owner_user_id) VALUES ('00000000-0000-0000-0000-0000000000a3', 'no-owner', 'No Owner', '00000000-0000-0000-0000-000000000003');
        SET CONSTRAINTS trg_shops_owner_guard IMMEDIATE;
        RAISE EXCEPTION 'owner guard: shop without owner member not rejected';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  SET CONSTRAINTS ALL DEFERRED;
  BEGIN UPDATE shops SET owner_user_id = '00000000-0000-0000-0000-000000000003' WHERE id = '00000000-0000-0000-0000-0000000000a1';
        SET CONSTRAINTS trg_shops_owner_guard IMMEDIATE;
        RAISE EXCEPTION 'owner guard: shops.owner_user_id not matching the owner member not rejected';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  SET CONSTRAINTS ALL DEFERRED;
  BEGIN INSERT INTO shop_ownership_transfers (shop_id, from_user_id, to_user_id, to_member_id, initiator_reauth_at, expires_at)
        VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002',
                '00000000-0000-0000-0000-000000000203', now(), now() + interval '1 day');
        RAISE EXCEPTION 'CHECK from_user_id <> to_user_id not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO shop_invitations (shop_id, email, role, token_hash, invited_by, expires_at)
        VALUES ('00000000-0000-0000-0000-0000000000a1', 'new.staff@EXAMPLE.test', 'STORE_VIEWER', 'inv-h2', '00000000-0000-0000-0000-000000000002', now() + interval '1 day');
        RAISE EXCEPTION 'partial UNIQUE pending invitation (shop, lower(email)) not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO platform_roles (user_id, role) VALUES ('00000000-0000-0000-0000-000000000004', 'PLATFORM_ADMIN');
        RAISE EXCEPTION 'partial UNIQUE one active platform role per user not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO shop_customers (shop_id, user_id, display_name) VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000001', 'Dup');
        RAISE EXCEPTION 'partial UNIQUE shop_customers(shop_id, user_id) not enforced';
  EXCEPTION WHEN unique_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO audit_logs (actor_type, action, resource_type, outcome) VALUES ('SERVICE', 'JOB_RUN', 'job', 'SUCCESS');
        RAISE EXCEPTION 'CHECK audit_logs SERVICE requires service_name not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO audit_logs (actor_type, action, resource_type, outcome) VALUES ('USER', 'X', 'x', 'OK');
        RAISE EXCEPTION 'CHECK audit_logs.outcome not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO inventory_ledger (shop_id, sku_id, entry_type, quantity_delta, on_hand_before, on_hand_after, idempotency_key, actor_type)
        VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2', 'ADJUST', -1, 10, 9, 'adj-noreason', 'USER');
        RAISE EXCEPTION 'CHECK ADJUST requires reason not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO refunds (order_id, shop_id, payment_id, amount, idempotency_key)
        VALUES ('00000000-0000-0000-0000-0000000000d1', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000f1', 0, 'ref-zero');
        RAISE EXCEPTION 'CHECK refunds.amount > 0 not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  BEGIN INSERT INTO auth_permissions (code, module, scope, policy_version) VALUES ('product-create', 'PRODUCT', 'STORE', '1.0');
        RAISE EXCEPTION 'CHECK auth_permissions.code format not enforced';
  EXCEPTION WHEN check_violation THEN ok := ok + 1; END;
  RAISE NOTICE 'smoke_test authz: % / 15 negative checks rejected as expected', ok;
  IF ok <> 15 THEN RAISE EXCEPTION 'authz negatives: only % / 15', ok; END IF;
END $$;

-- ownership transfer — atomic happy path: PENDING → (one pending per shop) → demote → promote → shops.owner_user_id → COMPLETED
INSERT INTO shop_ownership_transfers (id, shop_id, from_user_id, to_user_id, to_member_id, initiator_reauth_at, expires_at)
VALUES ('00000000-0000-0000-0000-000000000501', '00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000002',
        '00000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000203', now(), now() + interval '1 day');
DO $$ BEGIN
  BEGIN INSERT INTO shop_ownership_transfers (shop_id, from_user_id, to_user_id, to_member_id, initiator_reauth_at, expires_at)
        VALUES ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000003',
                '00000000-0000-0000-0000-000000000203', now(), now() + interval '1 day');
        RAISE EXCEPTION 'partial UNIQUE one PENDING transfer per shop not enforced';
  EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'second PENDING transfer rejected as expected'; END;
END $$;
UPDATE shop_members SET role = 'STORE_ADMIN', permission_version = permission_version + 1
 WHERE shop_id = '00000000-0000-0000-0000-0000000000a1' AND user_id = '00000000-0000-0000-0000-000000000002';
UPDATE shop_members SET role = 'STORE_OWNER', permission_version = permission_version + 1
 WHERE id = '00000000-0000-0000-0000-000000000203';
UPDATE shops SET owner_user_id = '00000000-0000-0000-0000-000000000003' WHERE id = '00000000-0000-0000-0000-0000000000a1';
UPDATE shop_ownership_transfers SET status = 'COMPLETED', accepted_at = now(), recipient_reauth_at = now(), completed_at = now()
 WHERE id = '00000000-0000-0000-0000-000000000501';
SET CONSTRAINTS trg_shops_owner_guard, trg_shop_members_owner_guard IMMEDIATE;   -- would raise if the swap were incomplete
SET CONSTRAINTS ALL DEFERRED;
SELECT s.owner_user_id = m.user_id AS transfer_consistent, m.role, t.status AS transfer_status
  FROM shops s JOIN shop_members m ON m.shop_id = s.id AND m.role = 'STORE_OWNER' AND m.status = 'ACTIVE'
  JOIN shop_ownership_transfers t ON t.shop_id = s.id WHERE s.id = '00000000-0000-0000-0000-0000000000a1';

-- ON DELETE CASCADE / SET NULL sanity: deleting the cart line cascades nothing unexpected
SELECT (SELECT count(*) FROM users) AS users, (SELECT count(*) FROM orders) AS orders,
       (SELECT count(*) FROM order_items) AS order_items, (SELECT count(*) FROM payments) AS payments,
       (SELECT count(*) FROM shipment_tracking_events) AS tracking_events,
       (SELECT status FROM orders WHERE id = '00000000-0000-0000-0000-0000000000d1') AS final_order_status;

ROLLBACK;
SELECT count(*) AS users_after_rollback FROM users;
