#!/usr/bin/env python3
"""Generate ThaiShopFun Ecommerce PostgreSQL schema Excel workbook."""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime, timezone, timedelta
from collections import OrderedDict, Counter

BKK = timezone(timedelta(hours=7))
NOW = datetime.now(BKK).strftime("%Y-%m-%d %H:%M ICT")

HDR_FILL = PatternFill("solid", fgColor="1F4E79")
HDR_FONT = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
MOD_FILLS = {
    "Auth & Identity": PatternFill("solid", fgColor="D6EAF8"),
    "Merchant Onboarding": PatternFill("solid", fgColor="D5F5E3"),
    "Shop & Team": PatternFill("solid", fgColor="FCF3CF"),
    "Catalog": PatternFill("solid", fgColor="FADBD8"),
    "Inventory": PatternFill("solid", fgColor="E8DAEF"),
    "Cart & Checkout": PatternFill("solid", fgColor="D5F5E3"),
    "Orders": PatternFill("solid", fgColor="FDEBD0"),
    "Payments": PatternFill("solid", fgColor="D6EAF8"),
    "Shipping": PatternFill("solid", fgColor="F5B7B1"),
    "Promotions": PatternFill("solid", fgColor="ABEBC6"),
    "Reviews": PatternFill("solid", fgColor="F9E79F"),
    "Content": PatternFill("solid", fgColor="AED6F1"),
    "Returns & Cancellations": PatternFill("solid", fgColor="F5CBA7"),
    "Notifications & Jobs": PatternFill("solid", fgColor="D7BDE2"),
    "Audit & Platform": PatternFill("solid", fgColor="CACFD2"),
    "OMS Integration": PatternFill("solid", fgColor="F1948A"),
    "Media": PatternFill("solid", fgColor="A9CCE3"),
}
THIN = Border(
    left=Side(style="thin", color="BFBFBF"),
    right=Side(style="thin", color="BFBFBF"),
    top=Side(style="thin", color="BFBFBF"),
    bottom=Side(style="thin", color="BFBFBF"),
)

def style_header(ws, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(1, c)
        cell.fill = HDR_FILL
        cell.font = HDR_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

def autosize(ws, max_width=48):
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        length = 0
        for cell in col:
            if cell.value:
                length = max(length, min(len(str(cell.value)), max_width))
        ws.column_dimensions[letter].width = max(12, length + 2)

def add_row(ws, values, fill=None):
    ws.append(values)
    r = ws.max_row
    for c, _ in enumerate(values, 1):
        cell = ws.cell(r, c)
        cell.border = THIN
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        if fill and c == 1:
            cell.fill = fill

def col(module, table, column, dtype, pk="", fk="", nullable="YES", unique="", default="", desc=""):
    return [module, table, column, dtype, pk, fk, nullable, unique, default, desc]

cols = []
AUTH = "Auth & Identity"
ONB = "Merchant Onboarding"
SHOP = "Shop & Team"
CAT = "Catalog"
INV = "Inventory"
CART = "Cart & Checkout"
ORD = "Orders"
PAY = "Payments"
SHIP = "Shipping"
PROMO = "Promotions"
REV = "Reviews"
CNT = "Content"
RET = "Returns & Cancellations"
MED = "Media"
JOB = "Notifications & Jobs"
AUD = "Audit & Platform"
OMS = "OMS Integration"

import sys
sys.path.insert(0, "/workspace/ecommerce-schema")
from schema_data_auth import add_auth_onb_shop
from schema_data_catalog import add_catalog_inv_cart
from schema_data_orders import add_orders_pay_ship
from schema_data_rest import add_rest_modules
from schema_meta import MODULES, RELS, OMS_ROWS, ER_NOTES, PROCESS_MAP
from schema_enums import ENUMS

add_auth_onb_shop(col, cols, AUTH, ONB, SHOP)
add_catalog_inv_cart(col, cols, CAT, INV, CART)
add_orders_pay_ship(col, cols, ORD, PAY, SHIP)
add_rest_modules(col, cols, PROMO, REV, CNT, RET, MED, JOB, AUD, OMS)
from schema_audit import check_audit
print(f"audit-field standard OK: {check_audit(cols, RELS)} tables end with created_date_time, created_by, modified_date_time, modified_by")

table_module = OrderedDict()
for row in cols:
    table_module.setdefault(row[1], row[0])
module_table_counts = Counter(table_module.values())
all_tables = list(table_module.keys())

wb = Workbook()

# --- Overview ---
ws = wb.active
ws.title = "Overview"
ws.append(["ThaiShopFun — Ecommerce PostgreSQL Schema (Senior Design) — v3 Phase 1 end-to-end evidence + authz (Role and Permission Matrix v1.1 merged 2026-10-04)"])
ws.append([f"Generated: {NOW} | Version: v3 + authz / 2026-10-04 (permission support: shop_customers, shop_ownership_transfers, merchant_application_reviews, auth_* read-only catalog — see Permission_Support; audit-field standard: created_date_time/created_by/modified_date_time/modified_by on all tables; TIMESTAMPTZ shown in Asia/Bangkok) | Target: PostgreSQL 17 | Payment-first → merchant confirm → inventory deduct → OMS push → ship/track → DELIVERED → COMPLETED | No COD"])
ws.append([])
ws.append(["Module", "Tables (summary)", "Table Count", "Purpose", "Owner System"])
for c in range(1, 6):
    cell = ws.cell(4, c)
    cell.fill = HDR_FILL
    cell.font = HDR_FONT
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
ws.freeze_panes = "A5"

for mod, tables_sum, purpose, owner in MODULES:
    cnt = module_table_counts.get(mod, 0)
    fill = MOD_FILLS.get(mod)
    ws.append([mod, tables_sum, cnt, purpose, owner])
    r = ws.max_row
    for c in range(1, 6):
        ws.cell(r, c).border = THIN
        ws.cell(r, c).alignment = Alignment(wrap_text=True, vertical="top")
    if fill:
        ws.cell(r, 1).fill = fill

ws.append([])
ws.append(["TOTAL TABLES", "", len(all_tables), "", ""])
ws.append(["TOTAL COLUMNS (approx)", "", len(cols), "", ""])
ws.append([])
ws.append(["Full table list"])
ws.append(["#", "Module", "Table", "Owner System"])
for i, (t, m) in enumerate(table_module.items(), 1):
    owner = "OMS-pluggable" if m == "OMS Integration" else (
        "Ecommerce (+ OMS-pluggable fields)" if t in ("orders", "shipments", "return_requests") else "Ecommerce"
    )
    ws.append([i, m, t, owner])

autosize(ws, 60)
ws.column_dimensions["B"].width = 70
ws.column_dimensions["D"].width = 55

# --- Tables ---
ws = wb.create_sheet("Tables")
headers = ["Module", "Table", "Column", "Data Type (PostgreSQL)", "PK", "FK", "Nullable", "Unique", "Default", "Description (TH/EN)"]
ws.append(headers)
style_header(ws, len(headers))
for row in cols:
    fill = MOD_FILLS.get(row[0])
    add_row(ws, row, fill)
autosize(ws, 45)
ws.column_dimensions["J"].width = 55

# --- Relationships ---
ws = wb.create_sheet("Relationships")
headers = ["From Table", "From Column", "To Table", "To Column", "Cardinality", "On Delete", "Notes"]
ws.append(headers)
style_header(ws, len(headers))
for r in RELS:
    add_row(ws, list(r))
autosize(ws, 40)

# --- Enums_Status ---
ws = wb.create_sheet("Enums_Status")
headers = ["Enum / Status Group", "Value", "Description"]
ws.append(headers)
style_header(ws, len(headers))
for r in ENUMS:
    add_row(ws, list(r))
autosize(ws, 50)

# --- OMS_Integration ---
ws = wb.create_sheet("OMS_Integration")
headers = ["Table", "Field / Scope", "Type", "Owner", "Purpose / Hook", "How OMS team plugs in"]
ws.append(headers)
style_header(ws, len(headers))
for r in OMS_ROWS:
    add_row(ws, list(r), MOD_FILLS["OMS Integration"])
ws.append([])
ws.append(["Integration flow (summary) — v3 (payment-confirm + tracking/completion)"])
ws.append(["1. Shop connects OMS → insert oms_connections (ACTIVE) with external_shop_id + credentials"])
ws.append(["2. Checkout: create order PENDING_PAYMENT + payment INTENT + inventory RESERVE (ACTIVE); write order_financial_snapshots"])
ws.append(["3. PG webhook CAPTURED → payment CAPTURED; order → PAID_AWAITING_MERCHANT_CONFIRM; reservation → PAID_HOLD; seller sees money only (not SKUs)"])
ws.append(["4. Merchant confirms → merchant_order_confirmations + items_revealed_at; SALE_CONFIRM ledger deduct; reservation COMMITTED; outbox oms.order.push"])
ws.append(["5. Worker pushes to OMS AFTER merchant confirm only → oms_order_links + orders.oms_external_order_id (OMS never gets pre-confirm hidden items)"])
ws.append(["6. OMS updates status/label → oms_webhook_inbox → update orders/shipments + insert shipment_tracking_events (source=OMS, dedup external_event_id); POD → shipment_delivery_proofs (CARRIER_POD)"])
ws.append(["6b. v3: DELIVERED → orders.auto_complete_at; buyer confirm / auto job → orders COMPLETED (Ecommerce-owned; optional outbox oms.order.completed)"])
ws.append(["7. Pull path (Group B): oms_sync_checkpoints + job pulls channel orders (merchant_confirm_status=NOT_REQUIRED)"])
ws.append(["8. Cancel/expire before confirm → RELEASE reservation; refund after deduct → RESTOCK_REFUND"])
ws.append(["9. Failures → integration_events FAILED/DEAD + background_jobs retry (max 4)"])
autosize(ws, 55)
ws.column_dimensions["E"].width = 60
ws.column_dimensions["F"].width = 50

# --- Process_Evidence_Map (v3) ---
ws = wb.create_sheet("Process_Evidence_Map")
headers = ["Phase", "Step", "Lane", "Evidence", "Table", "Column(s)", "Status value", "Notes"]
ws.append(headers)
style_header(ws, len(headers))
import re as _re
colset = {(r[1], r[2]) for r in cols}
_bad = []
for r in PROCESS_MAP:
    for t in [x.strip() for x in r[4].split("+")]:
        if t not in table_module:
            _bad.append(("table", t))
    for t, c in _re.findall(r"\b([a-z_]+)\.([a-z_]+)\b", r[5]):
        if (t, c) not in colset:
            _bad.append(("column", f"{t}.{c}"))
    first_tbl = r[4].split("+")[0].strip()
    add_row(ws, list(r), MOD_FILLS.get(table_module.get(first_tbl)))
assert not _bad, f"Process_Evidence_Map references unknown: {_bad}"
widths = {"A": 10, "B": 26, "C": 16, "D": 34, "E": 40, "F": 70, "G": 36, "H": 40}
for k, v in widths.items():
    ws.column_dimensions[k].width = v

# --- ER_Notes ---
ws = wb.create_sheet("ER_Notes")
headers = ["Topic", "Decision / Note"]
ws.append(headers)
style_header(ws, len(headers))
for r in ER_NOTES:
    add_row(ws, list(r))
ws.column_dimensions["A"].width = 22
ws.column_dimensions["B"].width = 100

# --- Permission_Support (authz 2026-10-04) ---
from schema_permission_support import rows as _perm_rows
from schema_meta import CONSTRAINTS_EXTRA, TRIGGERS_EXTRA
import schema_authz_catalog as _cat
ws = wb.create_sheet("Permission_Support")
ws.append(["Role and Permission Matrix v1.1 → schema v3 (+authz) — สถานะหลังรวม P01–P17 เข้า v3 (2026-10-04). Enforcement จริงอยู่ในโค้ด; ตารางนี้บอกว่า DB รองรับข้อกำหนดด้วยอะไร"])
ws.cell(1, 1).font = Font(bold=True, size=12)
headers = ["Req", "Doc section", "Area", "Requirement (doc)", "Status before", "Status after merge", "DB support (tables / constraints)", "Columns (validated)", "Enforcement (app layer)", "Change ref"]
ws.append(headers)
for c in range(1, len(headers) + 1):
    cell = ws.cell(2, c); cell.fill = HDR_FILL; cell.font = HDR_FONT
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
_ST_FILL = {"Supported": PatternFill("solid", fgColor="C6EFCE"), "Partial": PatternFill("solid", fgColor="FFEB9C"),
            "Not supported": PatternFill("solid", fgColor="FFC7CE"), "App-layer": PatternFill("solid", fgColor="DDEBF7")}
_bad = []
_pr = _perm_rows()
for r in _pr:
    for ref in r["refs"]:
        t, c = ref.split(".")
        if (t, c) not in colset: _bad.append(ref)
    ws.append([r["id"], r["section"], r["area"], r["requirement"], r["status_before"], r["status_after"], r["db_support"],
               ", ".join(r["refs"]), r["enforcement"], r["proposal"]])
    rr = ws.max_row
    for c in range(1, len(headers) + 1):
        ws.cell(rr, c).border = THIN; ws.cell(rr, c).alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(rr, 5).fill = _ST_FILL.get(r["status_before"], PatternFill())
    ws.cell(rr, 6).fill = _ST_FILL.get(r["status_after"], PatternFill())
assert not _bad, f"Permission_Support references unknown columns: {_bad}"
_cnt = Counter(r["status_after"] for r in _pr); _cnt0 = Counter(r["status_before"] for r in _pr)
ws.append([])
ws.append(["Summary", "", "", "", "before: " + ", ".join(f"{k} {v}" for k, v in _cnt0.items()), "after: " + ", ".join(f"{k} {v}" for k, v in _cnt.items())])
ws.append([])
ws.append(["DB guarantees (authz)", "kind", "table", "name", "definition", "note"])
for c in range(1, 7):
    ws.cell(ws.max_row, c).fill = HDR_FILL; ws.cell(ws.max_row, c).font = HDR_FONT
for x in CONSTRAINTS_EXTRA:
    d = x["expr"] + (f"  WHERE {x['where']}" if x.get("where") else "")
    ws.append(["", x["kind"], x["table"], x["name"], d, x["note"]])
for tx in TRIGGERS_EXTRA:
    for t, n, ev in tx["triggers"]:
        ws.append(["", "constraint trigger (DEFERRABLE INITIALLY DEFERRED)", t, n, ev + f" → {tx['function']}()", "Owner ACTIVE 1 คน = shops.owner_user_id"])
ws.append([])
ws.append(["Permission catalog (READ-ONLY reference)", "role", "context", "assignable", "permissions", "name_th"])
for c in range(1, 7):
    ws.cell(ws.max_row, c).fill = HDR_FILL; ws.cell(ws.max_row, c).font = HDR_FONT
_rp = Counter(r for r, _ in _cat.ROLE_PERMISSIONS)
for code, ctx, nth, dth, assignable, so in _cat.ROLES:
    ws.append(["", code, ctx, "yes" if assignable else "no", _rp.get(code, 0), nth])
ws.append(["", "TOTAL", f"{len(_cat.ROLES)} roles", "", f"{len(_cat.PERMISSIONS)} permissions / {len(_cat.ROLE_PERMISSIONS)} mappings", f"policy_version {_cat.POLICY_VERSION}"])
for k, v in {"A": 8, "B": 12, "C": 16, "D": 50, "E": 14, "F": 16, "G": 60, "H": 50, "I": 45, "J": 12}.items():
    ws.column_dimensions[k].width = v
ws.freeze_panes = "A3"

out = "/workspace/ecommerce-schema/Ecommerce_PostgreSQL_Schema.xlsx"
wb.save(out)
print(f"Saved: {out}")
print(f"Tables: {len(all_tables)}")
print(f"Columns: {len(cols)}")
print(f"Relationships: {len(RELS)}")
print(f"Enums: {len(ENUMS)}")
print(f"Process map rows: {len(PROCESS_MAP)}")
print("--- Module counts ---")
for mod, _, _, _ in MODULES:
    print(f"  {mod}: {module_table_counts.get(mod, 0)}")
print("TABLES_CSV=" + ",".join(all_tables))
