-- schema_snapshot.sql — deterministic catalog dump used to diff two databases
-- (full script vs. Flyway V1+V2+V3). Column order is ignored on purpose.
\pset format unaligned
\pset tuples_only on
SELECT 'COL|' || table_name || '|' || column_name || '|' || data_type
       || coalesce('(' || character_maximum_length || ')', '')
       || coalesce('(' || numeric_precision || ',' || numeric_scale || ')', '')
       || '|' || is_nullable || '|' || coalesce(column_default, '')
  FROM information_schema.columns
 WHERE table_schema = 'public' AND table_name <> 'flyway_schema_history'
 ORDER BY 1;
SELECT 'CON|' || r.relname || '|' || c.conname || '|' || pg_get_constraintdef(c.oid)
  FROM pg_constraint c JOIN pg_class r ON r.oid = c.conrelid JOIN pg_namespace n ON n.oid = r.relnamespace
 WHERE n.nspname = 'public' AND r.relname <> 'flyway_schema_history'
 ORDER BY 1;
SELECT 'IDX|' || indexname || '|' || indexdef FROM pg_indexes
 WHERE schemaname = 'public' AND tablename <> 'flyway_schema_history' ORDER BY 1;
SELECT 'TRG|' || r.relname || '|' || t.tgname || '|' || pg_get_triggerdef(t.oid)
  FROM pg_trigger t JOIN pg_class r ON r.oid = t.tgrelid JOIN pg_namespace n ON n.oid = r.relnamespace
 WHERE n.nspname = 'public' AND NOT t.tgisinternal ORDER BY 1;
SELECT 'CMT|' || r.relname || '|' || coalesce(a.attname, '<table>') || '|' || md5(d.description)
  FROM pg_description d JOIN pg_class r ON r.oid = d.objoid AND d.classoid = 'pg_class'::regclass
  JOIN pg_namespace n ON n.oid = r.relnamespace
  LEFT JOIN pg_attribute a ON a.attrelid = r.oid AND a.attnum = d.objsubid AND d.objsubid > 0
 WHERE n.nspname = 'public' AND r.relkind = 'r' ORDER BY 1;
SELECT 'FN|' || p.proname || '|' || md5(p.prosrc)
  FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
 WHERE n.nspname = 'public' ORDER BY 1;
