#!/usr/bin/env bash
# run_validation.sh — validates every SQL deliverable on a real PostgreSQL server.
# Needs psql/createdb/dropdb on PATH and a role allowed to create databases (PG* env vars respected).
# Usage:  bash sql/tests/run_validation.sh [path/to/existing_flyway_dir_with_V1_V2]
set -euo pipefail
SQL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
EXISTING="${1:-$SQL_DIR/../flyway_existing}"
PSQL="psql -X -q -v ON_ERROR_STOP=1"
DB1=ecom_v3_full; DB2=ecom_v3_flyway; DB3=ecom_v3_empty_v3only; DB4=ecom_v3_flyway_dirty; DB5=ecom_v3_flyway_dupapp
step() { echo; echo "=== $* ==="; }
# database-level timezone set by the scripts (ALTER DATABASE ... SET timezone) — independent of the server default
dbtz() {
  local cfg; cfg=$(psql -X -At -d postgres -c "select array_to_string(s.setconfig, ',') from pg_db_role_setting s join pg_database d on d.oid = s.setdatabase where d.datname = '$1' and s.setrole = 0")
  echo "SHOW timezone ($1, new session): $(psql -X -At -d "$1" -c 'show timezone') | database setting: ${cfg:-<none>}"
  [[ "$cfg" == *"TimeZone=Asia/Bangkok"* ]] || { echo "database $1 timezone not set to Asia/Bangkok"; exit 1; }
}
for d in $DB1 $DB2 $DB3 $DB4 $DB5; do dropdb --if-exists "$d"; createdb "$d"; done
echo "server default timezone: $(psql -X -At -d postgres -c 'show timezone')"

step "1. full script on fresh DB ($DB1)"
$PSQL -d $DB1 -f "$SQL_DIR/ecommerce_schema_v3_full.sql"
dbtz $DB1
$PSQL -d $DB1 -v audit_order=strict -f "$SQL_DIR/tests/verify_schema.sql"
$PSQL -d $DB1 -f "$SQL_DIR/tests/schema_snapshot.sql" -o /tmp/snap_full.txt

step "2. drop_all.sql, then modules in order"
$PSQL -d $DB1 -f "$SQL_DIR/drop_all.sql"
left=$(psql -X -At -d $DB1 -c "select count(*) from information_schema.tables where table_schema='public'")
echo "tables after drop_all: $left"; [ "$left" = "0" ]
for f in "$SQL_DIR"/modules/*.sql; do echo "  -> $(basename "$f")"; $PSQL -d $DB1 -f "$f"; done
$PSQL -d $DB1 -v audit_order=strict -f "$SQL_DIR/tests/verify_schema.sql"
$PSQL -d $DB1 -f "$SQL_DIR/tests/schema_snapshot.sql" -o /tmp/snap_modules.txt
diff /tmp/snap_full.txt /tmp/snap_modules.txt && echo "modules == full: identical catalog"

catalog_counts() {   # authz read-only catalog: 10 roles / 62 permissions / 150 mappings
  local c; c=$(psql -X -At -d "$1" -c "select (select count(*) from auth_roles)||'/'||(select count(*) from auth_permissions where is_active)||'/'||(select count(*) from auth_role_permissions)")
  echo "auth catalog ($1) roles/permissions/mappings = $c"; [ "$c" = "10/62/150" ] || { echo "catalog counts wrong"; exit 1; }
}
step "3. seed_reference_data.sql (x3 = idempotent; without and with admin_email) + authz catalog"
$PSQL -d $DB1 -f "$SQL_DIR/seed_reference_data.sql"
catalog_counts $DB1
snap_seed() { psql -X -At -d $DB1 -c "select md5(string_agg(x, '|' order by x)) from (
    select 'r:'||code||context||coalesce(name_th,'')||is_assignable||sort_order||policy_version||modified_date_time x from auth_roles
    union all select 'p:'||code||module||scope||is_active||modified_date_time from auth_permissions
    union all select 'm:'||r.code||'>'||p.code||m.modified_date_time from auth_role_permissions m join auth_roles r on r.id=m.role_id join auth_permissions p on p.id=m.permission_id
    union all select 's:'||setting_key||setting_value::text||is_admin_editable||modified_date_time from platform_settings) z"; }
h1=$(snap_seed)
$PSQL -d $DB1 -c "insert into users(first_name,last_name,email,phone,password_hash) values ('Admin','Seed','admin@example.test','0899999999','x')"
$PSQL -d $DB1 -v admin_email=admin@example.test -f "$SQL_DIR/seed_reference_data.sql"
$PSQL -d $DB1 -v admin_email=admin@example.test -f "$SQL_DIR/seed_reference_data.sql"
h3=$(snap_seed); catalog_counts $DB1
echo "reference data fingerprint run1=$h1 run3=$h3"; [ "$h1" = "$h3" ] || { echo "seed not idempotent (rows rewritten)"; exit 1; }
[ "$(psql -X -At -d $DB1 -c "select count(*) from platform_roles where revoked_at is null")" = "1" ] || { echo "platform_roles seed not idempotent"; exit 1; }
# catalog drift repair: a stale mapping is removed, a missing one re-added, a changed description restored
$PSQL -d $DB1 -c "insert into auth_role_permissions(role_id, permission_id, policy_version) select r.id, p.id, 'x' from auth_roles r, auth_permissions p where r.code='STORE_VIEWER' and p.code='SHOP_CLOSE'"
$PSQL -d $DB1 -c "delete from auth_role_permissions where role_id=(select id from auth_roles where code='STORE_OWNER') and permission_id=(select id from auth_permissions where code='SHOP_READ')"
$PSQL -d $DB1 -c "update auth_permissions set description_th='tampered' where code='SHOP_READ'"
$PSQL -d $DB1 -f "$SQL_DIR/seed_reference_data.sql"
catalog_counts $DB1
[ "$(psql -X -At -d $DB1 -c "select count(*) from auth_permissions where description_th='tampered'")" = "0" ] || { echo "catalog drift not repaired"; exit 1; }
psql -X -d $DB1 -c "select setting_key, setting_value, is_admin_editable from platform_settings" -c "select u.email, r.role, r.grant_reason from platform_roles r join users u on u.id=r.user_id" \
     -c "select r.code, r.context, count(m.id) permissions from auth_roles r left join auth_role_permissions m on m.role_id=r.id group by r.code, r.context, r.sort_order order by r.sort_order"
$PSQL -d $DB1 -c "delete from platform_roles; delete from users;"

step "4. smoke test (transaction + ROLLBACK)"
$PSQL -d $DB1 -f "$SQL_DIR/tests/smoke_test.sql"

step "4b. authz owner guard at real COMMIT (deferred constraint triggers)"
$PSQL -d $DB1 -c "insert into users(id,first_name,last_name,email,phone,password_hash) values ('00000000-0000-0000-0000-00000000c001','O','W','ow@example.test','0870000001','x'),('00000000-0000-0000-0000-00000000c002','N','O','no@example.test','0870000002','x')"
# (a) shop + owner member in one transaction commits
$PSQL -d $DB1 -c "begin; insert into shops(id,slug,name,owner_user_id) values ('00000000-0000-0000-0000-00000000c0a1','guard-ok','Guard OK','00000000-0000-0000-0000-00000000c001');
  insert into shop_members(shop_id,user_id,role) values ('00000000-0000-0000-0000-00000000c0a1','00000000-0000-0000-0000-00000000c001','STORE_OWNER'); commit;"
echo "OK: shop + owner member committed"
# (b) shop without owner member must fail at COMMIT
if psql -X -q -v ON_ERROR_STOP=1 -d $DB1 -c "begin; insert into shops(id,slug,name,owner_user_id) values ('00000000-0000-0000-0000-00000000c0a2','guard-bad','Guard Bad','00000000-0000-0000-0000-00000000c002'); commit;" 2>/tmp/guard.err; then
  echo "UNEXPECTED: shop without owner committed"; exit 1; else echo "OK: rejected at COMMIT: $(grep -o 'shop .* must have exactly one ACTIVE STORE_OWNER[^(]*' /tmp/guard.err | head -1)"; fi
# (c) removing the only owner must fail at COMMIT; (d) closing the shop first allows it
if psql -X -q -v ON_ERROR_STOP=1 -d $DB1 -c "update shop_members set status='INACTIVE' where shop_id='00000000-0000-0000-0000-00000000c0a1'" 2>/dev/null; then
  echo "UNEXPECTED: owner deactivated"; exit 1; else echo "OK: deactivating the only owner rejected"; fi
$PSQL -d $DB1 -c "begin; update shops set status='CLOSED', closed_at=now() where id='00000000-0000-0000-0000-00000000c0a1'; update shop_members set status='INACTIVE' where shop_id='00000000-0000-0000-0000-00000000c0a1'; commit;"
echo "OK: CLOSED shop may have no active owner"
$PSQL -d $DB1 -c "delete from shops; delete from users;"

step "5. Flyway: V1 + V2 (existing) + V3 on fresh DB ($DB2)"
V3="$SQL_DIR/flyway/V3__ecommerce_schema_v3.sql"
if [ -f "$V3" ] && ls "$EXISTING"/V1__*.sql >/dev/null 2>&1; then
  $PSQL -d $DB2 -f "$EXISTING"/V1__*.sql
  $PSQL -d $DB2 -f "$EXISTING"/V2__*.sql
  # simulate pre-existing production rows (fixed old timestamps) to prove V3 renames keep the data
  $PSQL -d $DB2 -c "insert into users values ('00000000-0000-0000-0000-0000000000aa','Old','User','old@example.test','0811111111','x','CUSTOMER','ACTIVE','2025-01-01 10:00:00+07','2025-06-01 12:00:00+07')"
  $PSQL -d $DB2 -c "insert into users values ('00000000-0000-0000-0000-0000000000ad','Old','Admin','oldadmin@example.test','0811111112','x','ADMIN','ACTIVE','2025-01-01 10:00:00+07','2025-01-01 10:00:00+07')"
  $PSQL -d $DB2 -c "insert into refresh_tokens values (gen_random_uuid(),'00000000-0000-0000-0000-0000000000aa','tokhash1',now()+interval '7 days',null,'2025-02-02 08:00:00+07')"
  $PSQL -d $DB2 -c "insert into merchant_applications(id,user_id,status,created_at,updated_at) values ('00000000-0000-0000-0000-0000000000ab','00000000-0000-0000-0000-0000000000aa','SUBMITTED','2025-03-03 09:00:00+07','2025-03-04 09:30:00+07')"
  $PSQL -d $DB2 -c "insert into merchant_documents values (gen_random_uuid(),'00000000-0000-0000-0000-0000000000ab','LOGO','a.png','b.png','/x/b.png','image/png',10,'abc','2025-03-03 09:05:00+07')"
  $PSQL -d $DB2 -1 -f "$V3"          # -1 = single transaction, like Flyway
  dbtz $DB2
  echo "--- rows after V3 (renamed audit columns must keep the original values) ---"
  psql -X -d $DB2 -c "select 'users' t, created_date_time, modified_date_time, created_by, modified_by from users
                      union all select 'refresh_tokens', created_date_time, modified_date_time, created_by, modified_by from refresh_tokens
                      union all select 'merchant_applications', created_date_time, modified_date_time, created_by, modified_by from merchant_applications
                      union all select 'merchant_documents', created_date_time, modified_date_time, created_by, modified_by from merchant_documents"
  $PSQL -d $DB2 -c "DO \$\$ BEGIN
    IF (SELECT created_date_time FROM users WHERE id = '00000000-0000-0000-0000-0000000000aa') <> '2025-01-01 10:00:00+07' OR (SELECT modified_date_time FROM users WHERE id = '00000000-0000-0000-0000-0000000000aa') <> '2025-06-01 12:00:00+07'
    THEN RAISE EXCEPTION 'users audit data not preserved'; END IF;
    IF (SELECT created_date_time FROM refresh_tokens) <> '2025-02-02 08:00:00+07' OR (SELECT modified_date_time FROM refresh_tokens) <> '2025-02-02 08:00:00+07'
    THEN RAISE EXCEPTION 'refresh_tokens audit data not preserved/backfilled'; END IF;
    IF (SELECT created_date_time FROM merchant_applications) <> '2025-03-03 09:00:00+07' OR (SELECT modified_date_time FROM merchant_applications) <> '2025-03-04 09:30:00+07'
    THEN RAISE EXCEPTION 'merchant_applications audit data not preserved'; END IF;
    IF (SELECT created_date_time FROM merchant_documents) <> '2025-03-03 09:05:00+07' OR (SELECT modified_date_time FROM merchant_documents) <> '2025-03-03 09:05:00+07'
    THEN RAISE EXCEPTION 'merchant_documents audit backfill (uploaded_at) wrong'; END IF;
    RAISE NOTICE 'V3 rename/backfill: existing V1/V2 audit data preserved (4 tables)'; END \$\$;"
  echo "--- authz: users.role deprecation step 1 (ADMIN copied to platform_roles, column kept + deprecated) ---"
  psql -X -d $DB2 -c "select u.email, u.role legacy_role, r.role, r.grant_reason from platform_roles r join users u on u.id=r.user_id" \
       -c "select col_description('users'::regclass, (select attnum from pg_attribute where attrelid='users'::regclass and attname='role')) as users_role_comment"
  $PSQL -d $DB2 -c "DO \$\$ BEGIN
    IF (SELECT count(*) FROM platform_roles WHERE user_id = '00000000-0000-0000-0000-0000000000ad' AND role = 'PLATFORM_ADMIN' AND revoked_at IS NULL) <> 1
       OR (SELECT count(*) FROM platform_roles) <> 1 THEN RAISE EXCEPTION 'ADMIN backfill to platform_roles wrong'; END IF;
    IF col_description('users'::regclass, (SELECT attnum FROM pg_attribute WHERE attrelid='users'::regclass AND attname='role')) NOT LIKE '%DEPRECATED%'
       THEN RAISE EXCEPTION 'users.role not marked DEPRECATED'; END IF;
    IF NOT (SELECT convalidated FROM pg_constraint WHERE conname = 'ck_merchant_applications_reviewer_not_applicant') THEN RAISE EXCEPTION 'clean data: CHECK should be validated'; END IF;
    RAISE NOTICE 'authz V3: ADMIN backfilled, users.role kept+deprecated, merchant_applications CHECK validated'; END \$\$;"
  catalog_counts $DB2
  $PSQL -d $DB2 -c "update users set first_name='Old2' where id='00000000-0000-0000-0000-0000000000aa'"
  $PSQL -d $DB2 -c "DO \$\$ BEGIN IF (SELECT modified_date_time FROM users WHERE id='00000000-0000-0000-0000-0000000000aa') <= '2025-06-01 12:00:00+07' THEN RAISE EXCEPTION 'trigger trg_users_modified_date_time did not fire'; END IF;
    RAISE NOTICE 'trg_users_modified_date_time fired on migrated V1 table (created_date_time kept, modified_date_time bumped)'; END \$\$;"
  $PSQL -d $DB2 -f "$SQL_DIR/tests/verify_schema.sql"
  $PSQL -d $DB2 -c "delete from merchant_applications; delete from refresh_tokens; delete from platform_roles; delete from users;"
  $PSQL -d $DB2 -f "$SQL_DIR/tests/smoke_test.sql"
  $PSQL -d $DB2 -f "$SQL_DIR/tests/schema_snapshot.sql" -o /tmp/snap_flyway.txt
  echo "--- catalog diff full vs V1+V2+V3 (expected: only legacy ix_merchant_applications_status; column order ignored) ---"
  diff /tmp/snap_full.txt /tmp/snap_flyway.txt || true
else
  echo "V3 or existing V1/V2 not found — skipped"
fi

step "5b. V1 + V2 (+ out-of-band reviewer_id) with a self-reviewed application, then V3 ($DB4) — CHECK added NOT VALID + WARNING (data kept)"
if [ -f "$V3" ]; then
  $PSQL -d $DB4 -f "$EXISTING"/V1__*.sql
  $PSQL -d $DB4 -f "$EXISTING"/V2__*.sql
  $PSQL -d $DB4 -c "insert into users values ('00000000-0000-0000-0000-0000000000ba','Self','Reviewer','self@example.test','0822222222','x','ADMIN','ACTIVE',now(),now())"
  # V2 has no reviewer_id; simulate an out-of-band hotfix column on the shared DB so the V3 guard has dirty data to handle
  $PSQL -d $DB4 -c "alter table merchant_applications add column reviewer_id uuid"
  $PSQL -d $DB4 -c "insert into merchant_applications(id,user_id,status,reviewer_id,created_at,updated_at) values ('00000000-0000-0000-0000-0000000000bb','00000000-0000-0000-0000-0000000000ba','APPROVED','00000000-0000-0000-0000-0000000000ba',now(),now())"
  $PSQL -d $DB4 -1 -f "$V3" 2>&1 | grep -E "WARNING" || true
  $PSQL -d $DB4 -c "DO \$\$ BEGIN
    IF (SELECT convalidated FROM pg_constraint WHERE conname = 'ck_merchant_applications_reviewer_not_applicant') THEN RAISE EXCEPTION 'expected NOT VALID'; END IF;
    IF (SELECT count(*) FROM merchant_applications) <> 1 THEN RAISE EXCEPTION 'legacy row lost'; END IF;
    BEGIN INSERT INTO merchant_applications(user_id,status,reviewer_id) VALUES ('00000000-0000-0000-0000-0000000000ba','DRAFT','00000000-0000-0000-0000-0000000000ba');
          RAISE EXCEPTION 'NOT VALID CHECK must still reject new rows';
    EXCEPTION WHEN check_violation THEN NULL; END;
    RAISE NOTICE 'dirty V2 data: V3 applied, CHECK NOT VALID (legacy row kept), new self-review rejected'; END \$\$;"
  echo "--- 5c. duplicate OPEN applications (V2 UNIQUE(user_id) dropped out-of-band) -> V3 must stop with a remediation message ($DB5) ---"
  $PSQL -d $DB5 -f "$EXISTING"/V1__*.sql
  $PSQL -d $DB5 -f "$EXISTING"/V2__*.sql
  $PSQL -d $DB5 -c "alter table merchant_applications drop constraint merchant_applications_user_id_key"
  $PSQL -d $DB5 -c "insert into users values ('00000000-0000-0000-0000-0000000000ca','Dup','App','dup@example.test','0833333333','x','CUSTOMER','ACTIVE',now(),now())"
  $PSQL -d $DB5 -c "insert into merchant_applications(id,user_id,status,created_at,updated_at) values (gen_random_uuid(),'00000000-0000-0000-0000-0000000000ca','DRAFT',now(),now()),(gen_random_uuid(),'00000000-0000-0000-0000-0000000000ca','SUBMITTED',now(),now())"
  if $PSQL -d $DB5 -1 -f "$V3" >/tmp/v3dup.log 2>&1; then echo "UNEXPECTED: V3 accepted duplicate open applications"; exit 1; fi
  echo "OK: V3 stopped (rolled back): $(grep -o 'uq_merchant_applications_user_id_open: duplicate[^\"]*re-run V3' /tmp/v3dup.log | head -1)"
  [ "$(psql -X -At -d $DB5 -c "select count(*) from information_schema.tables where table_name='shops'")" = "0" ] || { echo "V3 not rolled back"; exit 1; }
fi

step "6. V3 file alone on a fresh empty DB ($DB3) — must FAIL (it requires V1/V2 first)"
if $PSQL -d $DB3 -1 -f "$V3" >/dev/null 2>&1; then echo "UNEXPECTED: V3 ran without V1/V2"; exit 1; else echo "OK: V3 correctly requires V1/V2 (fails fast, rolled back)"; fi

step "7. (optional) real Flyway CLI: V1+V2+V3 — set FLYWAY=/path/to/flyway and PGPASSWORD"
if [ -n "${FLYWAY:-}" ]; then
  tmp=$(mktemp -d); cp "$EXISTING"/V1__*.sql "$EXISTING"/V2__*.sql "$V3" "$tmp"/
  dropdb --if-exists ecom_v3_fwcli; createdb ecom_v3_fwcli
  "$FLYWAY" -url="jdbc:postgresql://${PGHOST:-localhost}:${PGPORT:-5432}/ecom_v3_fwcli" -user="${PGUSER:-$USER}" \
            -password="${PGPASSWORD:-}" -locations="filesystem:$tmp" migrate
  dbtz ecom_v3_fwcli
  $PSQL -d ecom_v3_fwcli -f "$SQL_DIR/tests/verify_schema.sql"
  catalog_counts ecom_v3_fwcli
  psql -X -d ecom_v3_fwcli -c "select version, description, success from flyway_schema_history order by installed_rank"
else
  echo "FLYWAY not set — skipped"
fi

echo; echo "ALL VALIDATION STEPS PASSED"
