# ThaiShopFun Ecommerce: สคริปต์ SQL ของ PostgreSQL (schema v3 + authz, 2026-10-04 · audit-field standard + เวลาไทย + Role and Permission Matrix)

สคริปต์ทุกไฟล์ในโฟลเดอร์นี้ **สร้างอัตโนมัติ** ด้วย `../generate_sql.py`
ข้อมูลต้นทางคือ `schema_data_*.py`, `schema_meta.py` และ `schema_enums.py` ซึ่งเป็นชุดเดียวกับที่ใช้สร้าง `Ecommerce_PostgreSQL_Schema.xlsx`
ตัว generator จะเทียบข้อมูลกับชีต Tables / Relationships / Enums_Status ใน xlsx ทุกครั้ง ถ้าไม่ตรงกันจะหยุดทันที
**ห้ามแก้ไฟล์ .sql ด้วยมือ** ให้แก้ที่ข้อมูลต้นทาง แล้วสั่ง `python generate_sql.py` ใหม่

| ค่า | จำนวน |
|---|---|
| ตาราง | 70 (authz +6: auth_roles, auth_permissions, auth_role_permissions, merchant_application_reviews, shop_customers, shop_ownership_transfers) |
| คอลัมน์ | 1,103 (รวม audit 4 คอลัมน์ × 70 ตาราง = 280) |
| Foreign key | 173 (v3 152 + authz 21) |
| UNIQUE | 53 constraint + partial/expression unique index 7 ตัว (authz 6) |
| CHECK | 84 (authz: 7 กฎข้อมูล + enum CHECK ของคอลัมน์ใหม่) |
| Index (รวม PK/UNIQUE) | 288 |
| trigger `modified_date_time` | 70 ตาราง (ทุกตาราง) + constraint trigger authz 2 ตัว (owner guard) |
| COMMENT | ตาราง 70, คอลัมน์ 740 |

ทดสอบกับ **PostgreSQL 17.11** (Debian) แล้ว และใช้ได้กับ PostgreSQL 15 ขึ้นไป (เพราะใช้ `CREATE OR REPLACE TRIGGER` ซึ่งต้องเป็น PG14+ และ `gen_random_uuid()` ที่ติดมากับ core ตั้งแต่ PG13)

## โครงสร้างไฟล์

```
sql/
├── ecommerce_schema_v3_full.sql      ติดตั้งใหม่บน DB ว่าง (ทั้งไฟล์อยู่ใน BEGIN/COMMIT เดียว)
├── modules/                          ไฟล์เดียวกันแต่แยกตามโมดูล ให้รันตามลำดับเลข
│   ├── 00_extensions_functions.sql   timezone Asia/Bangkok + pgcrypto + ฟังก์ชัน set_modified_date_time()
│   ├── 01_auth.sql … 17_oms_integration.sql
│   └── 99_foreign_keys.sql           FK ทั้ง 173 ตัว (ต้องรันเป็นไฟล์สุดท้าย)
├── drop_all.sql                      ลบทั้ง 70 ตาราง (CASCADE) และฟังก์ชัน (รวม check_shop_single_owner) ใช้รีเซ็ต DB dev
├── seed_reference_data.sql           ข้อมูลอ้างอิงที่เอกสารกำหนด + catalog สิทธิ์ (10 roles / 62 permissions / 150 mappings)
├── flyway/V3__ecommerce_schema_v3.sql  migration ต่อจาก V1/V2 ของ backend (รวม authz + seed catalog + ADMIN backfill)
├── tests/
│   ├── verify_schema.sql             ตรวจจำนวนตาราง/FK/PK/index/ชื่อ constraint/trigger + audit 4 คอลัมน์ + timezone
│   ├── smoke_test.sql                happy path + negative 10 + authz negative 15 + โอนเจ้าของ แล้ว ROLLBACK
│   ├── schema_snapshot.sql           dump catalog ไว้ใช้ diff ระหว่าง 2 DB
│   ├── run_validation.sh             รันการทดสอบทั้งหมดตามลำดับ
│   ├── validation_log_2026-10-02.txt log รอบ audit standard
│   └── validation_log_2026-10-04_authz.txt log รอบ authz (ล่าสุด)
├── GENERATOR_REPORT.txt              mapping ระหว่าง enum กับ CHECK, รายการ unique/index และสมมติฐาน
└── README_TH.md
```

## วิธีรัน (psql)

ใส่ `-v ON_ERROR_STOP=1` ทุกครั้ง เพื่อให้หยุดทันทีเมื่อเจอ error แรก

```bash
# 1) ติดตั้งใหม่บน DB ว่าง (เลือกแบบใดแบบหนึ่ง)
createdb tsf_dev
psql -v ON_ERROR_STOP=1 -d tsf_dev -f ecommerce_schema_v3_full.sql

# หรือรันทีละโมดูลตามลำดับ
for f in modules/*.sql; do psql -v ON_ERROR_STOP=1 -d tsf_dev -f "$f" || break; done

# 2) ใส่ข้อมูลอ้างอิง (รันซ้ำได้ ไม่เกิดข้อมูลซ้ำ) — SQL มาตรฐาน ใช้ได้ทั้ง psql / pgAdmin / DBeaver
psql -v ON_ERROR_STOP=1 -d tsf_dev -f seed_reference_data.sql
#    ถ้าต้องการตั้ง PLATFORM_ADMIN ให้ user ที่มีอยู่แล้ว (ตั้งค่า session แล้วรัน seed อีกครั้ง)
psql -v ON_ERROR_STOP=1 -d tsf_dev -c "SELECT set_config('app.admin_email', 'admin@example.com', false);" -f seed_reference_data.sql
#    ใน pgAdmin: รัน SELECT set_config('app.admin_email', 'admin@example.com', false); ก่อน แล้วค่อยรันไฟล์ seed ทั้งไฟล์

# 3) ตรวจโครงสร้าง + smoke test (ไม่ทิ้งข้อมูลไว้ใน DB)
psql -v ON_ERROR_STOP=1 -d tsf_dev -f tests/verify_schema.sql
psql -v ON_ERROR_STOP=1 -d tsf_dev -f tests/smoke_test.sql

# 4) รีเซ็ต DB dev (ข้อมูลหายหมด!)
psql -v ON_ERROR_STOP=1 -d tsf_dev -f drop_all.sql
```

บน Windows (PowerShell) ใช้ `psql.exe` ได้เลย เช่น
`& "C:\Program Files\PostgreSQL\17\bin\psql.exe" -U postgres -v ON_ERROR_STOP=1 -d TSF_DB -f ecommerce_schema_v3_full.sql`
ถ้าข้อความภาษาไทยใน COMMENT เพี้ยน ให้ตั้ง `$env:PGCLIENTENCODING="UTF8"` ก่อนรัน

ลำดับไฟล์ใน `modules/` คือ `00` → `01 … 17` → `99`
FK ทุกตัวถูกแยกไว้ใน `99_foreign_keys.sql` เพราะในแบบมี FK ที่อ้างกันเป็นวง เช่น shops ↔ merchant_applications, shops ↔ media_files และ orders ↔ checkouts
ไฟล์ 00–17 จึงรันลำดับไหนก็ได้ แต่ไฟล์ 99 ต้องรันหลังสุดเสมอ

## CHECK กับ ENUM

เลือกเก็บค่าแบบ **`VARCHAR` + `CONSTRAINT ck_<table>_<column> CHECK (col IN (...))`** แทน `CREATE TYPE … AS ENUM` ด้วยเหตุผลต่อไปนี้

- ถ้าจะเพิ่มหรือลบค่า ทำได้ด้วยการ `DROP CONSTRAINT` แล้ว `ADD CONSTRAINT` ใหม่ภายใน migration เดียว ส่วน ENUM ลบค่าออกไม่ได้ และ `ALTER TYPE … ADD VALUE` ก็มีข้อจำกัดเรื่อง transaction
- ใช้กับ JPA `@Enumerated(EnumType.STRING)` และ `ddl-auto: validate` ได้ตรง ๆ เพราะเป็นแบบเดียวกับที่ V1/V2 ใช้อยู่ (VARCHAR)
- ค่าใน CHECK มาจากชีต **Enums_Status** เท่านั้น ส่วน mapping ว่าคอลัมน์ไหนใช้ enum กลุ่มไหน ดูได้ใน `GENERATOR_REPORT.txt`

กรณีพิเศษ:
- `shop_invitations.role` ใช้ store_role ทั้งหมด **ยกเว้น STORE_OWNER** ตามที่แบบเขียนไว้ว่า "ห้ามเชิญเป็น STORE_OWNER"
- `order_status_history.from_status/to_status` ใช้ order_status รวมกับ order_status (legacy) เพื่อให้เก็บประวัติเก่าได้
- `orders.oms_sync_status`, `oms_order_links.sync_status` และ `payments.provider`: ใน description เขียนค่าไว้เป็น subset แต่ CHECK ใช้ค่าทั้งกลุ่มใน Enums_Status
- `payments.provider` ไม่รับ `COD` (ระบบยังไม่รองรับ COD) และ smoke test ก็ตรวจข้อนี้ด้วย
- มีคอลัมน์ที่ description เขียนรายการค่าไว้ แต่ **ไม่มีกลุ่มใน Enums_Status** (หรือถูกยกเว้นด้วย NO_ENUM_CHECK เช่น `inventory_ledger.actor_type`) ทั้งหมด 17 คอลัมน์ เช่น `order_addresses.address_type`, `shipping_methods.carrier_code`, `media_files.status`, `notifications.channel`, `product_imports.status` คอลัมน์เหล่านี้ **ยังไม่ใส่ CHECK** (ดูรายการเต็มใน GENERATOR_REPORT.txt) ถ้าต้องการบังคับที่ DB ให้เพิ่มกลุ่มนั้นใน `schema_enums.py` แล้ว generate ใหม่
- CHECK อื่นที่ได้จาก description: `quantity > 0` (cart_items, order_items, inventory_reservations), `refunds.amount > 0` (authz) และ `product_reviews.rating BETWEEN 1 AND 5`
- authz: `merchant_application_reviews.from_status/to_status` ใช้กลุ่ม application_status (ENUM_OVERRIDES_EXTRA ใน schema_meta.py)

## UUID

- PK ของ entity ใช้ `UUID DEFAULT gen_random_uuid()` ซึ่งติดมากับ core ตั้งแต่ PG13 ไม่ต้องลง extension
  สคริปต์ full/modules ยังมี `CREATE EXTENSION IF NOT EXISTS pgcrypto;` ไว้ตามที่ขอ (ลบออกได้ถ้า user ไม่มีสิทธิ์ CREATE)
  ส่วนไฟล์ V3 ของ Flyway **ไม่ได้สร้าง pgcrypto** เพื่อไม่ต้องใช้สิทธิ์เพิ่ม
- ถ้าฝั่ง Java กำหนด id เอง (เช่น `UUID.randomUUID()` แบบที่โค้ดปัจจุบันทำ) ก็ใช้ได้ DEFAULT จะทำงานเฉพาะตอนที่ไม่ได้ส่ง id มา
- ตาราง append-only 7 ตัวใช้ `BIGSERIAL` ได้แก่ inventory_ledger, order_status_history, order_item_reveal_logs, audit_logs, outbox_events, integration_events และ shipment_tracking_events (ตาราง outbox_events และ integration_events มี `event_id UUID UNIQUE` แยกไว้สำหรับ idempotency)

## มาตรฐาน audit fields (ทุกตาราง 70/70)

ทุกตารางลงท้ายด้วย 4 คอลัมน์นี้ **ตามลำดับ** (แทน `created_at` / `updated_at` เดิม):

| คอลัมน์ | ชนิด | หมายเหตุ |
|---|---|---|
| `created_date_time` | `TIMESTAMPTZ NOT NULL DEFAULT now()` | เดิม `created_at` |
| `created_by` | `UUID NULL` | logical ref `users.id` (ไม่มี FK) · NULL = system/job/webhook |
| `modified_date_time` | `TIMESTAMPTZ NOT NULL DEFAULT now()` | เดิม `updated_at` · trigger ตั้งให้ทุก UPDATE |
| `modified_by` | `UUID NULL` | logical ref `users.id` (ไม่มี FK) · แอปเป็นคนตั้ง |

การตัดสินใจ:
1. rename `created_at` → `created_date_time`, `updated_at` → `modified_date_time` ทุกตาราง ตาราง append-only ที่ไม่เคยมี updated_at (audit_logs, inventory_ledger, order_status_history, outbox_events, integration_events, shipment_tracking_events ฯลฯ) ก็ได้ `modified_date_time` ด้วย (ตอน insert = created_date_time)
2. ตารางที่มี created_by/updated_by อยู่แล้ว: คง `created_by`, เปลี่ยน `updated_by` → `modified_by` และ **ลบ FK เดิม 7 ตัว** ให้ audit column เป็น UUID ธรรมดาเหมือนกันทุกตาราง (ไม่ผูก delete กับ users, ไม่ต้องมี FK เพิ่ม 128 ตัว):
   `products.created_by`, `products.updated_by`, `orders.created_by`, `promotions.created_by`, `background_jobs.created_by`, `product_imports.created_by` (เดิม NOT NULL + RESTRICT → ตอนนี้ nullable), `platform_settings.updated_by` → FK 159 → **152**
3. business timestamp อื่น (paid_at, confirmed_at, delivered_at, verified_at, expires_at, uploaded_at, occurred_at ฯลฯ) และ business actor (packed_by, verified_by, confirmed_by_user_id, uploaded_by, changed_by, granted_by, invited_by ฯลฯ) **คงเดิม**
4. index ที่อ้าง created_at เปลี่ยนชื่อตาม: `ix_orders_shop_id_created_date_time`, `ix_payment_proofs_shop_id_status_created_date_time`, `ix_otp_verifications_destination_hash_purpose_created_date_time`
5. generator (`schema_audit.py`) assert ทุกครั้งว่า 70 ตารางลงท้ายด้วย 4 คอลัมน์นี้ถูกชนิด/nullability/default ไม่มีชื่อ created_at/updated_at/updated_by และไม่มี FK บน audit column

## trigger `modified_date_time`

- ฟังก์ชัน `set_modified_date_time()` ตั้ง `NEW.modified_date_time := now()`
- ติด `trg_<table>_modified_date_time BEFORE UPDATE` ไว้ที่ **ทุกตาราง (70)**; `modified_by` แอปเป็นคนตั้ง
- `now()` คือเวลาเริ่ม transaction ดังนั้นแถวที่อัปเดตใน transaction เดียวกันจะได้เวลาเท่ากัน
- ถ้า JPA ตั้ง `modifiedDateTime` เองด้วย (`@PreUpdate` หรือ `@UpdateTimestamp`) จะไม่ขัดกัน แค่ค่าจาก trigger จะทับค่าจาก JPA

## Timezone: เวลาไทย (Asia/Bangkok, UTC+7)

- คอลัมน์เวลาทุกตัวเป็น `TIMESTAMPTZ` ซึ่งเก็บเป็นจุดเวลาจริง (absolute instant) จึงไม่เพี้ยนเมื่อ client อยู่คนละ timezone
- full script, `modules/00_extensions_functions.sql` และ Flyway V3 รัน `SET TIME ZONE 'Asia/Bangkok';` และ
  `DO $$ BEGIN EXECUTE format('ALTER DATABASE %I SET timezone TO %L', current_database(), 'Asia/Bangkok'); … END $$;`
  ผลคือ `now()` / DEFAULT และการแสดงผลเป็นเวลาไทย `+07` ทั้ง session ปัจจุบันและทุก connection ใหม่
- `ALTER DATABASE` ต้องเป็น owner ของ DB (หรือ superuser) ถ้า user ของ Flyway ไม่มีสิทธิ์ สคริปต์จะ `RAISE WARNING` แล้วทำต่อ (ไม่ fail) ให้ DBA รัน `ALTER DATABASE <db> SET timezone TO 'Asia/Bangkok';` เอง
- Spring Boot แนะนำ:
  ```yaml
  spring:
    jpa.properties.hibernate.jdbc.time_zone: Asia/Bangkok
    jackson.time-zone: Asia/Bangkok
  ```
  (หรือ `spring.jpa.properties.hibernate.jdbc.time_zone=Asia/Bangkok` และ `spring.jackson.time-zone=Asia/Bangkok`) และใช้ `OffsetDateTime` หรือ `Instant` ใน entity — **อย่าใช้ `LocalDateTime`** กับ TIMESTAMPTZ

## authz (Role and Permission Matrix v1.1, 2026-10-04)

ดูรายละเอียดใน `../CHANGELOG_AUTHZ_TH.md` — สรุปสิ่งที่อยู่ใน SQL:
- กฎที่ mini-language ใน description เขียนไม่ได้ ประกาศใน `schema_meta.CONSTRAINTS_EXTRA` (CHECK / partial-expression UNIQUE) และ `TRIGGERS_EXTRA` แล้ว generator สร้างให้ทุกไฟล์:
  - `uq_platform_roles_user_id_active` (WHERE revoked_at IS NULL) · `uq_merchant_applications_user_id_open` · `uq_shop_members_shop_id_owner` · `uq_shop_invitations_shop_id_email_pending` (lower(email)) · `uq_shop_customers_shop_id_user_id` · `uq_shop_ownership_transfers_shop_id_pending`
  - `ck_merchant_applications_reviewer_not_applicant` · `ck_shop_ownership_transfers_parties` · `ck_inventory_ledger_adjust_reason` · `ck_audit_logs_service_name` · `ck_auth_roles_code_format` · `ck_auth_permissions_code_format`
  - `check_shop_single_owner()` + `CREATE CONSTRAINT TRIGGER trg_shop_members_owner_guard / trg_shops_owner_guard … DEFERRABLE INITIALLY DEFERRED` — ตรวจตอน COMMIT ว่าร้านที่ไม่ CLOSED/ไม่ถูกลบ มี ACTIVE STORE_OWNER 1 คน = `shops.owner_user_id`
    - สร้างร้าน + owner member และการโอนเจ้าของ ต้องอยู่ใน transaction เดียว; ลำดับโอน: demote เจ้าของเดิม → promote ผู้รับ → update shops.owner_user_id
    - ทดสอบใน transaction ได้ด้วย `SET CONSTRAINTS trg_shops_owner_guard, trg_shop_members_owner_guard IMMEDIATE;`
- `auth_roles` / `auth_permissions` / `auth_role_permissions` = **READ-ONLY reference** (COMMENT ระบุ) — seed จาก `schema_authz_catalog.py`; แอปห้ามใช้ตัดสินสิทธิ์
- `users.role` COMMENT = DEPRECATED

## ชื่อ constraint และ index

`pk_<table>`, `fk_<table>_<column>`, `uq_<table>_<cols>`, `ck_<table>_<column>`, `ix_<table>_<cols>`, `trg_<table>_<name>` (ชื่อยาวไม่เกิน 63 ตัวอักษร; partial unique ของ authz ใช้ชื่อ `uq_<table>_<cols>_<qualifier>` เช่น `_active`, `_open`, `_pending`)

- คอลัมน์ FK มี index ทุกตัว แต่ถ้าคอลัมน์นั้นเป็นคอลัมน์แรกของ PK, UNIQUE หรือ index composite อยู่แล้ว จะไม่สร้าง index ซ้ำ (`verify_schema.sql` ตรวจให้ว่าไม่มี FK ที่ไม่มี index)
- index ที่ระบุไว้ใน description (`idx`, `idx(...)`) และในหัวข้อ "Indexes" ของ ER_NOTES ถูกสร้างครบ รวมถึง partial index `ix_orders_status_auto_complete_at … WHERE status='DELIVERED'`

## Flyway (Spring Boot backend)

`flyway/V3__ecommerce_schema_v3.sql` สร้างจากการอ่าน V1/V2 จริงในเครื่อง (`V1__create_auth_tables.sql` และ `V2__create_merchant_applications.sql`)
วิธีใช้: คัดลอกไฟล์ไปไว้ที่ `backend/src/main/resources/db/migration/`
**ห้ามแก้ V1/V2** เพราะ checksum จะเปลี่ยนแล้ว Flyway จะ validate ไม่ผ่าน

สิ่งที่ V3 ทำกับ 4 ตารางเดิม:
- **audit (ทั้ง 4 ตาราง):** `ALTER TABLE … RENAME COLUMN created_at TO created_date_time` / `updated_at TO modified_date_time` ห่อด้วย `DO $$ IF EXISTS (information_schema.columns …) $$` (ข้อมูลเดิมคงอยู่ ทดสอบแล้วด้วยแถวเก่า) แล้ว `ADD COLUMN IF NOT EXISTS created_by / modified_by / modified_date_time` ที่ยังไม่มี
  - `refresh_tokens.modified_date_time` (ใหม่) backfill = created_date_time; `merchant_documents.created_date_time`/`modified_date_time` (ใหม่) backfill = `uploaded_at`
  - คอลัมน์ที่ rename ใน 3 ตาราง (users, refresh_tokens, merchant_applications) จะ **ไม่อยู่ท้ายตารางทางกายภาพ** (PostgreSQL ย้ายลำดับคอลัมน์ไม่ได้) — ไม่มีผลต่อแอป/JPA; `verify_schema.sql` ตรวจลำดับแบบ strict เฉพาะการติดตั้งด้วย full/modules
- `users`: เพิ่มคอลัมน์ email_verified_at, phone_verified_at, last_login_at, permission_version (`NOT NULL DEFAULT 0`) และ deleted_at; ตั้ง DEFAULT ให้ id/role/status/created_date_time/modified_date_time; เพิ่ม CHECK ของ role และ status
- `refresh_tokens`: เพิ่มคอลัมน์ user_agent และ ip_address; ตั้ง DEFAULT ให้ id และ created_date_time
- `merchant_applications`: เพิ่มคอลัมน์ reviewer_id, review_note, shop_id (`UNIQUE`) และ reviewed_at; ตั้ง DEFAULT; เพิ่ม CHECK ของ status, sale_type และ owner_type
  - **ลบ UNIQUE(user_id) เดิม** (`merchant_applications_user_id_key`) แล้วแทนด้วย partial unique `uq_merchant_applications_user_id_open` (1 ใบที่ยังเปิดต่อ user — สมัครใหม่ได้หลัง REJECTED/WITHDRAWN/APPROVED)
    - guard: ถ้ามีใบเปิดซ้ำอยู่แล้ว V3 จะ `RAISE EXCEPTION` พร้อมวิธีแก้ (rollback ทั้งไฟล์) — ปกติไม่เกิดเพราะ V2 มี UNIQUE(user_id)
  - authz: เพิ่ม `withdrawn_at`; CHECK `ck_merchant_applications_reviewer_not_applicant` — ถ้าข้อมูลเดิมผิด จะเพิ่มแบบ `NOT VALID` + `RAISE WARNING` (แถวใหม่ยังถูกตรวจ; แก้ข้อมูลแล้ว `VALIDATE CONSTRAINT`)
- `users` (authz): เพิ่ม `suspended_at`, `suspended_by`, `suspend_reason_code`; **users.role deprecation step 1** — ท้ายไฟล์ V3 คัดลอก `users.role='ADMIN'` → `platform_roles` (PLATFORM_ADMIN, grant_reason 'V3 backfill …') ถ้ายังไม่มีแถว active; คงคอลัมน์ role + COMMENT DEPRECATED (DROP ใน migration ถัดไป)
- `merchant_documents`: ตั้ง DEFAULT ให้ id และ uploaded_at; เพิ่ม CHECK ของ document_type
- เปลี่ยนชื่อ constraint/index เดิมให้ตรงกับ convention เช่น `users_pkey`→`pk_users`, `users_email_key`→`uq_users_email`, `refresh_tokens_user_id_fkey`→`fk_refresh_tokens_user_id`, `uq_merchant_document_type`→`uq_merchant_documents_application_id_document_type`, `idx_refresh_tokens_user_id`→`ix_refresh_tokens_user_id`
  - ทุก rename ห่อด้วย `DO $$ IF EXISTS … $$` ถ้าไม่เจอชื่อเดิมก็จะข้ามไป
- `idx_merchant_applications_status` ไม่อยู่ในแบบ v3 แต่ **ไม่ลบทิ้ง** แค่เปลี่ยนชื่อเป็น `ix_merchant_applications_status`
  นี่คือจุดเดียวที่ catalog ต่างจากการติดตั้งด้วย full script
- ค่า enum ใน Java (UserRole, UserStatus, ApplicationStatus, DocumentType, OwnerType, SaleType) เป็น subset ของ CHECK ทั้งหมด ข้อมูลเดิมจึงผ่าน CHECK
- FK เดิม 3 ตัวที่มี ON DELETE CASCADE ตรงกับแบบอยู่แล้ว จึงแค่เปลี่ยนชื่อ ไม่สร้างใหม่
- ตารางที่เหลืออีก 66 ตารางถูก CREATE และ FK อีก 170 ตัวถูกเพิ่มต่อท้ายไฟล์ ตามด้วย constraint triggers (หลังโมดูล Shop & Team), ADMIN backfill และ seed catalog
- ถ้ามี DB dev ไหนเคยรัน V3 เวอร์ชันก่อนหน้า (ก่อน audit standard) ไปแล้ว checksum จะไม่ตรง ให้ `flyway clean`/สร้าง DB ใหม่ หรือทำเป็น V4 แทน (production ยังมีแค่ V1/V2 จึงใช้ V3 นี้ได้ตรง ๆ)

ข้อควรรู้เพิ่มเติม:
- ไฟล์ V3 ไม่มี `BEGIN/COMMIT` เพราะ Flyway ครอบแต่ละ migration ด้วย transaction ให้อยู่แล้ว
- บน DB ใหม่ Flyway จะรัน V1 → V2 → V3 ตามลำดับเอง ส่วนถ้ารัน V3 เดี่ยว ๆ บน DB ว่างจะ fail ทันที (ถูกต้องตามที่ควรเป็น)
- **JPA ต้องแก้ก่อน deploy V3** (backend ใช้ `ddl-auto: validate` — ถ้าไม่แก้ แอปจะ start ไม่ขึ้นเพราะหา `created_at`/`updated_at` ไม่เจอ):
  - `com/thaishopfun/auth/UserAccount.java` (users): `@Column(name = "created_at")` → `"created_date_time"`, `@Column(name = "updated_at")` → `"modified_date_time"` (field createdAt/updatedAt จะเปลี่ยนชื่อเป็น createdDateTime/modifiedDateTime ด้วยก็ได้)
  - `com/thaishopfun/auth/RefreshToken.java` (refresh_tokens): `created_at` → `created_date_time` (ไม่มี updatedAt — จะเพิ่ม modifiedDateTime ก็ได้)
  - `com/thaishopfun/merchant/MerchantApplication.java` (merchant_applications): `created_at`/`updated_at` → `created_date_time`/`modified_date_time` รวมถึง getter `getCreatedAt()`/`getUpdatedAt()` ถ้าเปลี่ยนชื่อ field
  - `com/thaishopfun/merchant/MerchantDocument.java`: ไม่ต้องแก้ (คอลัมน์ใหม่มี DEFAULT; validate ไม่ตรวจคอลัมน์ที่ไม่ได้ map)
  - optional: map `createdBy`/`modifiedBy` (UUID) และใช้ `@CreatedBy`/`@LastModifiedBy` ของ Spring Data
- `ddl-auto: validate` จะไม่ fail จากคอลัมน์ที่เพิ่มเข้ามา แต่ entity ใหม่ต้องประกาศ type ให้ตรง เช่น `INET` และ `JSONB` ต้องใช้ `@JdbcTypeCode(SqlTypes.JSON)` หรือ type ที่เหมาะสม และ `CHAR(3)` ต้องใช้ `columnDefinition` หรือ `@JdbcTypeCode(SqlTypes.CHAR)`
- seed catalog สิทธิ์ (auth_*) **อยู่ท้าย V3 แล้ว** (idempotent — SQL ธรรมดา); ส่วน platform_settings / PLATFORM_ADMIN ตาม email อยู่ใน `seed_reference_data.sql` (SQL ธรรมดาเช่นกัน — ตั้ง `app.admin_email` ด้วย `set_config` ถ้าต้องการแต่งตั้งแอดมิน)
- **V3 นี้ยังไม่ได้รันบน shared DB ของผู้ใช้** — ถ้า DB ใดเคยรัน V3 รุ่นก่อน (2026-10-02) ไปแล้ว checksum จะไม่ตรง ต้อง clean/สร้าง DB ใหม่
- `drop_all.sql` ไม่ลบ `flyway_schema_history` ถ้าใช้กับ DB ที่ Flyway ดูแลอยู่ ให้ใช้ `flyway clean` หรือลบตาราง history เองด้วย

## Seed: ข้อมูลอ้างอิงที่ใส่ให้

ใส่เฉพาะค่าที่เอกสารออกแบบกำหนดไว้จริงเท่านั้น
- `platform_settings`: `order.auto_complete_days = 7` (มาจาก ER_NOTES หัวข้อ "Order completion (v3)" และ CHANGELOG_V3_TH.md)
  - authz: ตั้ง `is_admin_editable = true` + `value_schema` (integer 1–30) + `description` (ไม่เขียนทับ setting_value เดิม)
- `platform_roles`: `PLATFORM_ADMIN` จะใส่ก็ต่อเมื่อตั้ง `SELECT set_config('app.admin_email', '…', false);` ให้ชี้ไปที่ user ที่มีอยู่แล้วเท่านั้น สคริปต์จะไม่สร้าง user ขึ้นมาเอง (`ON CONFLICT (user_id) WHERE revoked_at IS NULL DO NOTHING`)
- `auth_roles` 10 / `auth_permissions` 62 / `auth_role_permissions` 150 (Role and Permission Matrix v1.1, policy_version 1.0) — upsert by code เฉพาะเมื่อค่าเปลี่ยน, ลบ mapping ที่ไม่อยู่ใน catalog, permission ที่ถูกถอดออกเป็น is_active=false
- ส่วน `hub_categories`, `blog_categories`, `shipping_methods` ฯลฯ **ไม่ใส่** เพราะเอกสารไม่ได้กำหนดค่าไว้ จึงไม่แต่งข้อมูลธุรกิจขึ้นมาเอง

## สมมติฐาน / ข้อสังเกตจาก generator

1. UNIQUE ที่ได้จาก cardinality ในชีต Relationships ทั้งที่ชีต Tables ไม่ได้ติ๊ก Unique: `merchant_applications.shop_id` (1:0..1) และ `checkouts.order_id` (1:0..1)
2. `carts`: description เขียนว่า "UNIQUE(buyer_user_id,shop_id) WHERE active" จึงทำเป็น partial unique index `uq_carts_buyer_user_id_shop_id … WHERE status = 'ACTIVE'`
3. `shipment_tracking_events UNIQUE(shipment_id, external_event_id)`: ถ้า external_event_id เป็น NULL จะไม่ชนกัน ตามที่แบบเขียนไว้ (event ภายในไม่ต้องมี id)
4. Note ใน Relationships ที่เขียนว่า "V2 UNIQUE(type)" (merchant_documents) ไม่ได้ทำเพิ่ม เพราะ description มี UNIQUE(application_id, document_type) ครอบไว้แล้ว
5. FK ที่เป็น `ON DELETE SET NULL` ทุกตัวอยู่บนคอลัมน์ที่ nullable ทั้งหมด (generator ตรวจแล้ว)
6. ทุกอย่างอยู่ใน schema `public` และไม่ได้กำหนด owner หรือ GRANT ไว้ ให้จัดการตาม environment

## ผลการทดสอบ (2026-10-04 เวลาไทย, PostgreSQL 17.11, Flyway CLI 11.8.2) — ดู `tests/validation_log_2026-10-04_authz.txt`

| ขั้นตอน | ผล |
|---|---|
| full script บน DB ใหม่ | ✅ 70 ตาราง, 173 FK, 70 PK, FK ทุกตัวมี index, ชื่อ constraint ตรง convention (รวม constraint trigger `trg_*`); audit 280/280 + ลำดับท้ายตาราง (strict); trigger modified_date_time 70/70; authz: partial unique 6, CHECK 7, constraint trigger 2 (DEFERRABLE INITIALLY DEFERRED) |
| `drop_all.sql` แล้วรัน modules 00→17→99 | ✅ catalog เหมือน full script (ตาราง/คอลัมน์/constraint/index/trigger/comment/function body) |
| seed ×3 (ไม่มี/มี admin_email) | ✅ idempotent (fingerprint รอบ 1 = รอบ 3 รวม modified_date_time → ไม่มีการเขียนทับ); catalog 10/62/150; drift (mapping เกิน/ขาด, description ถูกแก้) ถูกซ่อมเมื่อรันซ้ำ |
| smoke test → ROLLBACK | ✅ negative เดิม 10/10 + authz 15/15 (ใบสมัครเปิดซ้ำ, self-review, Owner คนที่สอง, ปิด Owner คนเดียว, ร้านไม่มี Owner, owner_user_id ไม่ตรง, โอนให้ตัวเอง, คำเชิญ PENDING ซ้ำแบบตัวพิมพ์ต่าง, platform role active ซ้ำ, shop_customer ซ้ำ, SERVICE ไม่มี service_name, outcome ผิด, ADJUST ไม่มี reason, refund 0, รหัส permission ผิดรูปแบบ) + โอนเจ้าของ atomic สำเร็จ + PENDING ซ้ำถูกปฏิเสธ |
| owner guard ที่ COMMIT จริง | ✅ shop+owner commit ได้; shop ไม่มี owner → fail ตอน COMMIT; ปิด Owner คนเดียว → fail; ร้าน CLOSED ปิด Owner ได้ |
| V1+V2 (มีข้อมูล รวม user ADMIN) + V3 (psql `-1`) | ✅ ข้อมูล audit เดิมคงอยู่; ADMIN → platform_roles 1 แถว; users.role คงอยู่ + COMMENT DEPRECATED; CHECK self-review validated; catalog 10/62/150; catalog ต่างจาก full แค่ `ix_merchant_applications_status` |
| V2 ข้อมูลผิด (self-review ผ่านคอลัมน์ที่เพิ่มนอก migration) + V3 | ✅ V3 ผ่าน + WARNING, CHECK เป็น NOT VALID, แถวเดิมคงอยู่, แถวใหม่ยังถูกปฏิเสธ |
| V2 มีใบเปิดซ้ำ (UNIQUE เดิมถูกลบนอก migration) + V3 | ✅ V3 หยุดพร้อมข้อความวิธีแก้ และ rollback ทั้งไฟล์ |
| V1+V2+V3 ด้วย **Flyway CLI 11.8.2** จริง | ✅ "Successfully applied 3 migrations … now at version v3"; verify ผ่าน; catalog 10/62/150 |
| รัน V3 เดี่ยวบน DB ว่าง | ✅ fail ทันที |
| timezone | ✅ ทุก DB: `SHOW timezone` = Asia/Bangkok ใน session ใหม่ + `pg_db_role_setting` = TimeZone=Asia/Bangkok |

รันซ้ำ: `PGHOST=localhost PGUSER=… PGPASSWORD=… FLYWAY=/path/to/flyway bash sql/tests/run_validation.sh`

<details><summary>ผลการทดสอบรอบก่อน (2026-10-02, audit standard — 64 ตาราง)</summary>

### ผลการทดสอบ (2026-10-02 เวลาไทย, PostgreSQL 17.11, Flyway CLI 11.8.2) — ดู `tests/validation_log_2026-10-02.txt`

| ขั้นตอน | ผล |
|---|---|
| full script บน DB ใหม่ (`ON_ERROR_STOP=1`) | ✅ 64 ตาราง, 152 FK, 64 PK, FK ทุกตัวมี index, ชื่อ constraint ตรง convention 100%; audit 256/256 คอลัมน์ถูกต้อง + ลำดับท้ายตาราง (strict), ไม่มี created_at/updated_at/updated_by, ไม่มี FK บน audit column, trigger 64/64 |
| `drop_all.sql` แล้วรัน modules 00→17→99 | ✅ catalog เหมือน full script ทุกจุด (diff ว่าง) + verify strict ผ่าน |
| seed (รัน 3 รอบ ทั้งแบบมีและไม่มี admin_email) | ✅ idempotent |
| smoke test (happy path → COMPLETED) แล้ว ROLLBACK | ✅ negative 10/10; trigger modified_date_time ทำงาน (payments + ตาราง append-only inventory_ledger); modified_by เก็บได้; created_by รับ UUID ใดก็ได้ (ไม่มี FK); `created_date_time` แสดงเป็น `+07` |
| V1+V2 (มีแถวเดิมใน users, refresh_tokens, merchant_applications, merchant_documents) + V3 ด้วย psql `-1` | ✅ ค่าเวลาเดิมคงอยู่ครบหลัง rename (เช่น users 2025-01-01 10:00+07 / 2025-06-01 12:00+07), backfill ถูกต้อง, trigger ทำงานบนตารางเดิม; catalog ต่างจาก full แค่ `ix_merchant_applications_status` |
| V1+V2+V3 ด้วย **Flyway CLI จริง** | ✅ "Successfully applied 3 migrations" แล้ว verify ผ่าน |
| รัน V3 เดี่ยวบน DB ว่าง | ✅ fail ทันทีตามที่ควรเป็น |
| timezone | ✅ ทุก DB ที่ทดสอบ: `SHOW timezone` = `Asia/Bangkok` ใน session ใหม่ และ `pg_db_role_setting` = `TimeZone=Asia/Bangkok` (ยืนยันว่ามาจาก ALTER DATABASE ไม่ใช่ค่า default ของ server) |

รันซ้ำทั้งหมดได้ด้วย `bash sql/tests/run_validation.sh` (ใส่ `FLYWAY=/path/to/flyway PGPASSWORD=…` ด้วย ถ้าต้องการรันขั้นที่ใช้ Flyway CLI)

</details>
