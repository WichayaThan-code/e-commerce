#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate PostgreSQL DDL (v3) from the Ecommerce schema data scripts.

Source of truth: schema_data_*.py + schema_meta.py (RELS, ER_NOTES, MODULES) + schema_enums.py
(the same data used by generate_schema.py to build Ecommerce_PostgreSQL_Schema.xlsx).
The xlsx is cross-checked (Tables / Relationships / Enums_Status) so the SQL can never drift.

Outputs (sql/):
  ecommerce_schema_v3_full.sql, modules/NN_*.sql, modules/99_foreign_keys.sql,
  drop_all.sql, seed_reference_data.sql, flyway/V3__ecommerce_schema_v3.sql
Run:  python3 generate_sql.py   (after generate_schema.py)
"""
import os, re, sys, hashlib
from collections import OrderedDict

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
OUT = os.path.join(BASE, "sql")
VERSION, VDATE = "v3", "2026-10-04 authz"
EXISTING_FLYWAY_DIR = os.path.join(BASE, "flyway_existing")   # copies of backend V1/V2

# ----------------------------------------------------------------------------- load data
from schema_data_auth import add_auth_onb_shop
from schema_data_catalog import add_catalog_inv_cart
from schema_data_orders import add_orders_pay_ship
from schema_data_rest import add_rest_modules
from schema_meta import MODULES, RELS, ER_NOTES, CONSTRAINTS_EXTRA, ENUM_OVERRIDES_EXTRA, NO_ENUM_CHECK, TRIGGERS_EXTRA, V3_POST_SQL
import schema_authz_catalog as AUTHZ_CAT
from schema_enums import ENUMS
from schema_audit import check_audit, AUDIT_NAMES, TRIGGER_FN_NAME

def col(module, table, column, dtype, pk="", fk="", nullable="YES", unique="", default="", desc=""):
    return [module, table, column, dtype, pk, fk, nullable, unique, default, desc]

cols = []
add_auth_onb_shop(col, cols, "Auth & Identity", "Merchant Onboarding", "Shop & Team")
add_catalog_inv_cart(col, cols, "Catalog", "Inventory", "Cart & Checkout")
add_orders_pay_ship(col, cols, "Orders", "Payments", "Shipping")
add_rest_modules(col, cols, "Promotions", "Reviews", "Content", "Returns & Cancellations", "Media",
                 "Notifications & Jobs", "Audit & Platform", "OMS Integration")

N_AUDIT_TABLES = check_audit(cols, RELS)   # every table ends with the 4 standard audit columns, no FK on them
print(f"audit-field standard OK: {N_AUDIT_TABLES} tables")

WARN = []   # generator diagnostics -> printed + written to sql/GENERATOR_REPORT.txt
def warn(msg): WARN.append(msg)

# ---- cross-check with the Excel workbook (if present)
def crosscheck_xlsx():
    path = os.path.join(BASE, "Ecommerce_PostgreSQL_Schema.xlsx")
    if not os.path.exists(path):
        warn("xlsx not found — cross-check skipped"); return
    try:
        from openpyxl import load_workbook
    except ImportError:
        warn("openpyxl missing — xlsx cross-check skipped"); return
    wb = load_workbook(path, read_only=True)
    norm = lambda v: "" if v is None else str(v)
    t_rows = [[norm(c) for c in r] for r in wb["Tables"].iter_rows(min_row=2, values_only=True) if r[1]]
    r_rows = [tuple(norm(c) for c in r) for r in wb["Relationships"].iter_rows(min_row=2, values_only=True) if r[0]]
    e_rows = [tuple(norm(c) for c in r) for r in wb["Enums_Status"].iter_rows(min_row=2, values_only=True) if r[0]]
    py_cols = [[norm(c) for c in r] for r in cols]
    assert t_rows == py_cols, "Tables sheet differs from schema_data_*.py — re-run generate_schema.py"
    assert r_rows == [tuple(norm(c) for c in r) for r in RELS], "Relationships sheet differs from schema_meta.RELS"
    assert e_rows == [tuple(norm(c) for c in r) for r in ENUMS], "Enums_Status sheet differs from schema_enums.ENUMS"
    print(f"xlsx cross-check OK: {len(t_rows)} column rows, {len(r_rows)} relationships, {len(e_rows)} enum values")

# ----------------------------------------------------------------------------- model
TABLES = OrderedDict()          # table -> dict(module, cols=[...])
for m, t, c, dt, pk, fk, nul, uq, dflt, desc in cols:
    tb = TABLES.setdefault(t, {"module": m, "cols": OrderedDict()})
    assert c not in tb["cols"], f"duplicate column {t}.{c}"
    tb["cols"][c] = dict(name=c, type=dt.strip(), pk=pk == "PK", fk=fk, nullable=(nul.upper() != "NO"),
                         unique=(uq.upper() == "YES"), default=dflt.strip(), desc=desc.strip())

MODULE_ORDER = [m[0] for m in MODULES]
assert set(MODULE_ORDER) == {t["module"] for t in TABLES.values()}, "MODULES vs table modules mismatch"
MODULE_FILE = {
    "Auth & Identity": "auth", "Merchant Onboarding": "merchant", "Shop & Team": "shop",
    "Catalog": "catalog", "Inventory": "inventory", "Cart & Checkout": "cart_checkout",
    "Orders": "orders", "Payments": "payments", "Shipping": "shipping", "Promotions": "promotions",
    "Reviews": "reviews", "Content": "content", "Returns & Cancellations": "returns",
    "Media": "media", "Notifications & Jobs": "notifications_jobs", "Audit & Platform": "audit_platform",
    "OMS Integration": "oms_integration",
}

def ident_name(prefix, table, cols_):
    name = f"{prefix}_{table}_{'_'.join(cols_)}" if cols_ else f"{prefix}_{table}"
    if len(name) > 63:
        h = hashlib.md5(name.encode()).hexdigest()[:8]
        name = name[:54] + "_" + h
        warn(f"identifier truncated: {name}")
    return name

def q(s):  # SQL string literal
    return "'" + s.replace("'", "''") + "'"

# ---- enums
ENUM_GROUPS = OrderedDict()
for g, v, _d in ENUMS:
    ENUM_GROUPS.setdefault(g, []).append(v)

# Columns whose description carries no value list but which are clearly enum-typed in the design.
ENUM_OVERRIDES = {
    ("platform_roles", "role"): ["platform_role"],
    ("shop_invitations", "role"): ["store_role", "-STORE_OWNER"],      # 'ห้ามเชิญเป็น STORE_OWNER'
    ("order_financial_snapshots", "payment_status"): ["payment_status (order)"],  # copy of orders.payment_status
    ("shipments", "oms_sync_status"): ["oms_sync_status"],
    ("return_requests", "oms_sync_status"): ["oms_sync_status"],
    ("oms_shipment_links", "sync_status"): ["oms_sync_status"],
    ("shipment_tracking_events", "normalized_status"): ["shipment_status"],
    ("order_status_history", "from_status"): ["order_status", "order_status (legacy)"],
    ("order_status_history", "to_status"): ["order_status", "order_status (legacy)"],
}
ENUM_OVERRIDES.update(ENUM_OVERRIDES_EXTRA)   # authz (schema_meta)
LIST_RE = re.compile(r"^(?:v\d+:\s*|OMS plug:\s*)?([A-Z0-9_]+(?:\|[A-Z0-9_]+)+)")

ENUM_MAP = OrderedDict()   # (t,c) -> (group label, [values])
DESC_ONLY_LISTS = []       # (t,c,[values]) value lists in descriptions with no Enums_Status group
for t, tb in TABLES.items():
    for c, cd in tb["cols"].items():
        if (t, c) in ENUM_OVERRIDES:
            spec = ENUM_OVERRIDES[(t, c)]
            vals, labels = [], []
            for s in spec:
                if s.startswith("-"):
                    vals = [v for v in vals if v != s[1:]]; labels.append(f"except {s[1:]}")
                else:
                    vals += [v for v in ENUM_GROUPS[s] if v not in vals]; labels.append(s)
            ENUM_MAP[(t, c)] = (" + ".join(labels), vals)
            continue
        if not cd["type"].upper().startswith("VARCHAR"):
            continue
        if (t, c) in NO_ENUM_CHECK:
            warn(f"enum {t}.{c}: CHECK skipped by NO_ENUM_CHECK (value list kept in description)")
            DESC_ONLY_LISTS.append((t, c, cd["desc"].split()[0].split("|"))); continue
        m = LIST_RE.match(cd["desc"])
        if not m:
            continue
        vals = m.group(1).split("|")
        sv = set(vals)
        exact = [g for g, gv in ENUM_GROUPS.items() if set(gv) == sv]
        sup = sorted([g for g, gv in ENUM_GROUPS.items() if sv < set(gv)], key=lambda g: len(ENUM_GROUPS[g]))
        cands = exact or sup
        if not cands:
            DESC_ONLY_LISTS.append((t, c, vals)); continue
        # tie-break: group name overlapping table name, else first
        tok = lambda g: re.split(r"[ _(]", g)[0]
        best = [g for g in cands if tok(g) in t] or cands
        g = best[0]
        if not exact:
            warn(f"enum {t}.{c}: description lists {vals} ⊂ Enums_Status '{g}' — CHECK uses full group")
        ENUM_MAP[(t, c)] = (g, ENUM_GROUPS[g])

used_groups = set()
for lbl, _ in ENUM_MAP.values():
    for part in lbl.split(" + "):
        used_groups.add(part)
for g in ENUM_GROUPS:
    if g not in used_groups:
        warn(f"Enums_Status group '{g}' not mapped to any column")

# ---- PK / UNIQUE / CHECK / INDEX
for t, tb in TABLES.items():
    tb["pk"] = [c for c, cd in tb["cols"].items() if cd["pk"]]
    assert tb["pk"], f"{t} has no PK"
    tb["uniques"] = []      # list of (cols tuple, where or None, source)
    tb["checks"] = []       # (name, expr)
    tb["indexes"] = []      # (cols tuple, where, source)

def add_unique(t, cols_, where=None, source=""):
    tb = TABLES[t]
    cols_ = tuple(cols_)
    if cols_ == tuple(tb["pk"]) and where is None:
        return
    for u in tb["uniques"]:
        if u[0] == cols_ and u[1] == where:
            return
    tb["uniques"].append((cols_, where, source))

def resolve_col(t, token):
    cs = TABLES[t]["cols"]
    if token in cs: return token
    if token + "_id" in cs: return token + "_id"
    m = [c for c in cs if c.endswith("_id") and token in c]
    return m[0] if len(m) == 1 else None

WHERE_WORDS = {"active": lambda t: "status = 'ACTIVE'" if "status" in TABLES[t]["cols"] else "is_active"}
UQ_RE = re.compile(r"UNIQUE\(([^)]*)\)(?:\s*WHERE\s+(\w+))?")

for t, tb in TABLES.items():
    for c, cd in tb["cols"].items():
        if cd["unique"] and not cd["pk"]:
            add_unique(t, (c,), source="Unique=YES")
        for m in UQ_RE.finditer(cd["desc"]):
            toks = [x.strip() for x in m.group(1).split(",")]
            rc = [resolve_col(t, x) for x in toks]
            if None in rc:
                warn(f"cannot resolve UNIQUE({m.group(1)}) in {t}.{c} description"); continue
            where = WHERE_WORDS[m.group(2).lower()](t) if m.group(2) else None
            add_unique(t, rc, where, source=f"desc {t}.{c}")
for (ft, fc, tt, tc, card, ondel, note) in RELS:
    for m in UQ_RE.finditer(note):
        toks = [x.strip() for x in m.group(1).split(",")]
        rc = [resolve_col(ft, x) for x in toks]
        if None in rc:
            warn(f"Relationships note '{note}' ({ft}.{fc}): UNIQUE({m.group(1)}) not resolvable — skipped (already covered?)")
            continue
        add_unique(ft, rc, source=f"Relationships note {ft}.{fc}")
    if card in ("1:1", "1:0..1"):
        before = len(TABLES[ft]["uniques"])
        add_unique(ft, (fc,), source=f"cardinality {card}")
        if len(TABLES[ft]["uniques"]) > before:
            warn(f"UNIQUE({ft}.{fc}) added from Relationships cardinality {card} (not flagged Unique in Tables)")

# indexes from descriptions
IDX_RE = re.compile(r"\bidx\(([^)]*)\)")
IDX_BARE_RE = re.compile(r"\bidx\b(?!\()")
for t, tb in TABLES.items():
    for c, cd in tb["cols"].items():
        for m in IDX_RE.finditer(cd["desc"]):
            rc = [resolve_col(t, x.strip()) for x in m.group(1).split(",")]
            assert None not in rc, (t, c, m.group(0))
            tb["indexes"].append((tuple(rc), None, f"desc {t}.{c}"))
        if IDX_BARE_RE.search(cd["desc"]):
            tb["indexes"].append(((c,), None, f"desc {t}.{c} 'idx'"))

# indexes from ER_NOTES 'Indexes ...' rows
NOTE_IDX_RE = re.compile(r"(UNIQUE\s+)?([a-z_]+)\(([a-z_,\s]+)\)(?:\s+WHERE\s+([a-z_]+\s*=\s*'[A-Z_]+'))?")
for topic, text in ER_NOTES:
    if not topic.lower().startswith("indexes"):
        continue
    for m in NOTE_IDX_RE.finditer(text):
        tname = m.group(2)
        if tname not in TABLES:
            cand = [x for x in TABLES if x.startswith(tname)]
            if len(cand) != 1:
                warn(f"ER_NOTES index on unknown table '{tname}' skipped"); continue
            tname = cand[0]
        rc = [resolve_col(tname, x.strip()) for x in m.group(3).split(",")]
        assert None not in rc, m.group(0)
        if m.group(1):
            add_unique(tname, rc, source=f"ER_NOTES {topic}")
        else:
            TABLES[tname]["indexes"].append((tuple(rc), m.group(4), f"ER_NOTES {topic}"))

# FK model
FKS = []
fk_cols_flagged = {(t, c): cd["fk"] for t, tb in TABLES.items() for c, cd in tb["cols"].items() if cd["fk"]}
seen = set()
for (ft, fc, tt, tc, card, ondel, note) in RELS:
    assert ft in TABLES and fc in TABLES[ft]["cols"], f"RELS from {ft}.{fc} unknown"
    assert tt in TABLES and tc in TABLES[tt]["cols"], f"RELS to {tt}.{tc} unknown"
    assert (ft, fc) not in seen, f"duplicate FK {ft}.{fc}"; seen.add((ft, fc))
    od = ondel.strip().upper() or "NO ACTION"
    assert od in ("CASCADE", "SET NULL", "RESTRICT", "NO ACTION", "SET DEFAULT"), od
    if od == "SET NULL" and not TABLES[ft]["cols"][fc]["nullable"]:
        warn(f"FK {ft}.{fc} ON DELETE SET NULL but column is NOT NULL")
    flag = fk_cols_flagged.get((ft, fc))
    if flag != f"FK→{tt}.{tc}":
        warn(f"FK {ft}.{fc}->{tt}.{tc}: Tables sheet FK flag is '{flag}'")
    FKS.append(dict(table=ft, col=fc, ref_table=tt, ref_col=tc, on_delete=od, card=card, note=note,
                    name=ident_name("fk", ft, [fc])))
for k, v in fk_cols_flagged.items():
    if k not in seen:
        warn(f"Tables sheet flags {k[0]}.{k[1]} {v} but no Relationships row — FK not created")

# CHECKs: enums + simple numeric rules from descriptions
for t, tb in TABLES.items():
    for c, cd in tb["cols"].items():
        if (t, c) in ENUM_MAP:
            vals = ENUM_MAP[(t, c)][1]
            tb["checks"].append((ident_name("ck", t, [c]),
                                 f"{c} IN ({', '.join(q(v) for v in vals)})", f"enum {ENUM_MAP[(t, c)][0]}"))
        if re.match(r"^>\s*0\b", cd["desc"]):
            tb["checks"].append((ident_name("ck", t, [c]), f"{c} > 0", "desc '>0'"))
        m = re.match(r"^(\d+)-(\d+)$", cd["desc"])
        if m and cd["type"].upper() in ("SMALLINT", "INTEGER", "INT", "BIGINT"):
            tb["checks"].append((ident_name("ck", t, [c]), f"{c} BETWEEN {m.group(1)} AND {m.group(2)}", "desc range"))

# authz extras (schema_meta.CONSTRAINTS_EXTRA): CHECKs with arbitrary expressions + partial/expression UNIQUE indexes
EXTRA_CHECKS = set()
for t, tb in TABLES.items():
    tb["xuniques"] = []
for x in CONSTRAINTS_EXTRA:
    assert x["table"] in TABLES, x
    if x["kind"] == "check":
        TABLES[x["table"]]["checks"].append((x["name"], x["expr"], "authz: " + x["note"]))
        EXTRA_CHECKS.add(x["name"])
    elif x["kind"] == "partial_unique":
        TABLES[x["table"]]["xuniques"].append((x["name"], x["expr"], x.get("where"), "authz: " + x["note"]))
    else:
        raise ValueError(x)

# finalize indexes: dedupe, drop ones covered by PK/UNIQUE with same leading cols; add FK indexes
def leading_covered(t, cols_):
    tb = TABLES[t]
    cands = [tuple(tb["pk"])] + [u[0] for u in tb["uniques"] if u[1] is None] + [i[0] for i in tb["final_idx"] if i[1] is None]
    return any(cc[:len(cols_)] == tuple(cols_) for cc in cands)

for t, tb in TABLES.items():
    tb["final_idx"] = []
    for cols_, where, src in tb["indexes"]:
        if where is None and leading_covered(t, cols_):
            continue
        if any(i[0] == cols_ and i[1] == where for i in tb["final_idx"]):
            continue
        tb["final_idx"].append((cols_, where, src))
for fk in FKS:
    t = fk["table"]
    if not leading_covered(t, (fk["col"],)):
        TABLES[t]["final_idx"].append(((fk["col"],), None, "FK"))

# ----------------------------------------------------------------------------- SQL emitters
def col_def(cd):
    s = f"    {cd['name']} {cd['type']}"
    if cd["default"]:
        s += f" DEFAULT {cd['default']}"
    if not cd["nullable"] or cd["pk"]:
        s += " NOT NULL"
    return s

def uq_name(t, cols_):
    return ident_name("uq", t, list(cols_))

def ix_name(t, cols_, where=None):
    n = ident_name("ix", t, list(cols_))
    return n

def table_comment(t):
    tb = TABLES[t]
    pkd = tb["cols"][tb["pk"][0]]["desc"]
    base = f"[{tb['module']}]"
    if pkd and pkd.upper() != "PK" and not pkd.lower().startswith("primary key"):
        return base + " " + pkd
    purpose = next(m[2] for m in MODULES if m[0] == tb["module"])
    return f"{base} {t} — {purpose}"

def emit_create_table(t):
    tb = TABLES[t]
    lines = [col_def(cd) for cd in tb["cols"].values()]
    lines.append(f"    CONSTRAINT {ident_name('pk', t, [])} PRIMARY KEY ({', '.join(tb['pk'])})")
    for cols_, where, src in tb["uniques"]:
        if where is None:
            lines.append(f"    CONSTRAINT {uq_name(t, cols_)} UNIQUE ({', '.join(cols_)})")
    for name, expr, src in tb["checks"]:
        lines.append(f"    CONSTRAINT {name} CHECK ({expr})")
    return f"CREATE TABLE {t} (\n" + ",\n".join(lines) + "\n);\n"

def emit_partial_uniques(t, if_not_exists=False):
    out = []
    ine = "IF NOT EXISTS " if if_not_exists else ""
    for cols_, where, src in TABLES[t]["uniques"]:
        if where is not None:
            out.append(f"CREATE UNIQUE INDEX {ine}{uq_name(t, cols_)} ON {t} ({', '.join(cols_)}) WHERE {where};  -- {src}")
    for name, expr, where, src in TABLES[t]["xuniques"]:
        w = f" WHERE {where}" if where else ""
        out.append(f"CREATE UNIQUE INDEX {ine}{name} ON {t} ({expr}){w};  -- {src}")
    return out

def emit_indexes(t, if_not_exists=False):
    out = emit_partial_uniques(t, if_not_exists)
    ine = "IF NOT EXISTS " if if_not_exists else ""
    for cols_, where, src in TABLES[t]["final_idx"]:
        w = f" WHERE {where}" if where else ""
        out.append(f"CREATE INDEX {ine}{ix_name(t, cols_)} ON {t} ({', '.join(cols_)}){w};  -- {src}")
    return out

def emit_comments(t):
    out = [f"COMMENT ON TABLE {t} IS {q(table_comment(t))};"]
    for c, cd in TABLES[t]["cols"].items():
        d = cd["desc"]
        if (t, c) in ENUM_MAP:
            d = (d + " " if d else "") + f"[CHECK enum: {ENUM_MAP[(t, c)][0]}]"
        if d:
            out.append(f"COMMENT ON COLUMN {t}.{c} IS {q(d)};")
    return out

def trg_name(t):
    return ident_name("trg", t, ["modified_date_time"])

def emit_trigger(t, replace=False):
    if "modified_date_time" not in TABLES[t]["cols"]:
        return []
    kw = "CREATE OR REPLACE TRIGGER" if replace else "CREATE TRIGGER"
    return [f"{kw} {trg_name(t)} BEFORE UPDATE ON {t}\n    FOR EACH ROW EXECUTE FUNCTION {TRIGGER_FN_NAME}();"]

def emit_table_block(t):
    parts = [f"-- ---------------------------------------------------------------------------\n-- {t}\n-- ---------------------------------------------------------------------------",
             emit_create_table(t)]
    parts += emit_indexes(t)
    parts += emit_comments(t)
    parts += emit_trigger(t)
    return "\n".join(parts) + "\n"

def emit_extra_triggers(mod, replace=False):
    """authz constraint triggers owned by a module (schema_meta.TRIGGERS_EXTRA)."""
    out = []
    for tx in TRIGGERS_EXTRA:
        if tx["after_module"] != mod: continue
        out.append(f"-- authz: {tx['function']}() + constraint triggers (DEFERRABLE INITIALLY DEFERRED — checked at COMMIT)")
        out.append(tx["sql"])
        for t, name, event in tx["triggers"]:
            if replace:
                out.append(f"DROP TRIGGER IF EXISTS {name} ON {t};")
            out.append(f"CREATE CONSTRAINT TRIGGER {name} {event}\n    DEFERRABLE INITIALLY DEFERRED\n    FOR EACH ROW EXECUTE FUNCTION {tx['function']}();")
            out.append(f"COMMENT ON TRIGGER {name} ON {t} IS {q('authz: Owner ACTIVE 1 คน = shops.owner_user_id (ตรวจตอน COMMIT)')};")
    return "\n".join(out) + "\n" if out else ""

def catalog_seed_sql():
    """Idempotent seed of the READ-ONLY permission catalog (schema_authz_catalog.py)."""
    pv = AUTHZ_CAT.POLICY_VERSION
    b = lambda v: "true" if v else "false"
    roles = ",\n".join(f"    ({q(c)}, {q(ctx)}, {q(n)}, {q(d)}, {b(a)}, {so}, {q(pv)})" for c, ctx, n, d, a, so in AUTHZ_CAT.ROLES)
    perms = ",\n".join(f"    ({q(c)}, {q(m)}, {q(sc)}, {q(d)}, {q(sec)}, true, {q(pv)})" for c, m, sc, d, sec in AUTHZ_CAT.PERMISSIONS)
    pairs = ",\n".join(f"    ({q(r)}, {q(c)})" for r, c in AUTHZ_CAT.ROLE_PERMISSIONS)
    pcodes = ", ".join(q(c) for c, *_ in AUTHZ_CAT.PERMISSIONS)
    return f"""-- authz catalog (READ-ONLY reference; enforcement stays in code) — policy_version {pv}:
--   {len(AUTHZ_CAT.ROLES)} roles / {len(AUTHZ_CAT.PERMISSIONS)} permissions / {len(AUTHZ_CAT.ROLE_PERMISSIONS)} role→permission mappings (Role and Permission Matrix v1.1)
--   Idempotent: upsert by code (UPDATE only when something changed), mappings ON CONFLICT DO NOTHING,
--   mappings no longer in the catalog are deleted, permissions no longer in the catalog are deactivated (kept for audit history).
INSERT INTO auth_roles (code, context, name_th, description_th, is_assignable, sort_order, policy_version) VALUES
{roles}
ON CONFLICT (code) DO UPDATE SET context = EXCLUDED.context, name_th = EXCLUDED.name_th, description_th = EXCLUDED.description_th,
    is_assignable = EXCLUDED.is_assignable, sort_order = EXCLUDED.sort_order, policy_version = EXCLUDED.policy_version
WHERE (auth_roles.context, auth_roles.name_th, auth_roles.description_th, auth_roles.is_assignable, auth_roles.sort_order, auth_roles.policy_version)
      IS DISTINCT FROM (EXCLUDED.context, EXCLUDED.name_th, EXCLUDED.description_th, EXCLUDED.is_assignable, EXCLUDED.sort_order, EXCLUDED.policy_version);

INSERT INTO auth_permissions (code, module, scope, description_th, doc_section, is_active, policy_version) VALUES
{perms}
ON CONFLICT (code) DO UPDATE SET module = EXCLUDED.module, scope = EXCLUDED.scope, description_th = EXCLUDED.description_th,
    doc_section = EXCLUDED.doc_section, is_active = EXCLUDED.is_active, policy_version = EXCLUDED.policy_version
WHERE (auth_permissions.module, auth_permissions.scope, auth_permissions.description_th, auth_permissions.doc_section, auth_permissions.is_active, auth_permissions.policy_version)
      IS DISTINCT FROM (EXCLUDED.module, EXCLUDED.scope, EXCLUDED.description_th, EXCLUDED.doc_section, EXCLUDED.is_active, EXCLUDED.policy_version);

UPDATE auth_permissions SET is_active = false
 WHERE is_active AND code NOT IN ({pcodes});

WITH v(role_code, perm_code) AS (VALUES
{pairs}
), del AS (
    DELETE FROM auth_role_permissions arp
     USING auth_roles r, auth_permissions p
     WHERE arp.role_id = r.id AND arp.permission_id = p.id
       AND NOT EXISTS (SELECT 1 FROM v WHERE v.role_code = r.code AND v.perm_code = p.code)
)
INSERT INTO auth_role_permissions (role_id, permission_id, policy_version)
SELECT r.id, p.id, {q(pv)} FROM v
  JOIN auth_roles r ON r.code = v.role_code
  JOIN auth_permissions p ON p.code = v.perm_code
ON CONFLICT (role_id, permission_id) DO NOTHING;
"""

def emit_fk(fk):
    return (f"ALTER TABLE {fk['table']} ADD CONSTRAINT {fk['name']} FOREIGN KEY ({fk['col']}) "
            f"REFERENCES {fk['ref_table']} ({fk['ref_col']}) ON DELETE {fk['on_delete']};")

TRIGGER_FN = """CREATE OR REPLACE FUNCTION set_modified_date_time() RETURNS trigger
    LANGUAGE plpgsql AS $$
BEGIN
    NEW.modified_date_time := now();
    RETURN NEW;
END;
$$;
COMMENT ON FUNCTION set_modified_date_time() IS 'BEFORE UPDATE trigger (ทุกตาราง): ตั้ง modified_date_time = now() อัตโนมัติ; modified_by แอปเป็นผู้ตั้ง (ecommerce schema v3 audit standard)';
"""

# Thai time: TIMESTAMPTZ stores an absolute instant; session + database default timezone = Asia/Bangkok
TZ_SESSION = "SET TIME ZONE 'Asia/Bangkok';  -- now()/DEFAULT/display in Thai time (UTC+7); TIMESTAMPTZ still stores the absolute instant\n"
TZ_DATABASE = """-- Database default timezone = Asia/Bangkok (new connections). Needs DB owner/superuser; otherwise WARNING (ask the DBA).
DO $$ BEGIN
    EXECUTE format('ALTER DATABASE %I SET timezone TO %L', current_database(), 'Asia/Bangkok');
EXCEPTION WHEN insufficient_privilege THEN
    RAISE WARNING 'no privilege to ALTER DATABASE % SET timezone — set it manually (session timezone is Asia/Bangkok)', current_database();
END $$;
"""

def header(title, extra=""):
    return f"""-- =============================================================================
-- ThaiShopFun Ecommerce — PostgreSQL schema {VERSION} ({VDATE})
-- {title}
-- Target: PostgreSQL 15+ (validated on 17). Schema: public.
-- GENERATED by generate_sql.py from schema_data_*.py / schema_meta.py / schema_enums.py
-- (same source as Ecommerce_PostgreSQL_Schema.xlsx). DO NOT EDIT BY HAND — regenerate.
-- Conventions: pk_<table>, fk_<table>_<column>, uq_<table>_<cols>, ck_<table>_<column>,
--              ix_<table>_<cols>, trg_<table>_modified_date_time.
-- Audit standard: every table ends with created_date_time, created_by, modified_date_time, modified_by
--   (TIMESTAMPTZ NOT NULL DEFAULT now() / UUID NULL, logical ref users.id — no FK); set_modified_date_time() on UPDATE.
-- Timezone: all timestamps TIMESTAMPTZ, session/database timezone Asia/Bangkok (UTC+7).
-- Enums: VARCHAR + CHECK (... IN (...)) from Enums_Status (no native ENUM types — easier to migrate).
{extra}-- =============================================================================
"""

def module_tables(mod):
    return [t for t, tb in TABLES.items() if tb["module"] == mod]

# ----------------------------------------------------------------------------- existing V1/V2 parser
def parse_existing(dirpath):
    """Very small parser for the simple CREATE TABLE / CREATE INDEX statements in V1/V2."""
    sql = ""
    files = sorted(f for f in os.listdir(dirpath) if f.endswith(".sql")) if os.path.isdir(dirpath) else []
    for f in files:
        sql += open(os.path.join(dirpath, f), encoding="utf-8").read() + "\n"
    sql = re.sub(r"--[^\n]*", "", sql)
    tables, indexes = OrderedDict(), []
    for m in re.finditer(r"CREATE TABLE\s+(\w+)\s*\((.*?)\);", sql, re.S | re.I):
        t, body = m.group(1), m.group(2)
        items, depth, cur = [], 0, ""
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                items.append(cur.strip()); cur = ""
            else:
                cur += ch
        if cur.strip(): items.append(cur.strip())
        tcols, cons = OrderedDict(), []
        for it in items:
            mc = re.match(r"CONSTRAINT\s+(\w+)\s+UNIQUE\s*\(([^)]*)\)", it, re.I)
            if mc:
                cons.append(dict(kind="u", name=mc.group(1), cols=tuple(x.strip() for x in mc.group(2).split(","))))
                continue
            mcol = re.match(r"(\w+)\s+(.*)", it, re.S)
            name, rest = mcol.group(1), " ".join(mcol.group(2).split())
            typ = re.split(r"\s+(?:PRIMARY|NOT|NULL|UNIQUE|REFERENCES|DEFAULT)\b", rest, flags=re.I)[0].strip()
            typ = re.sub(r"TIMESTAMP WITH TIME ZONE", "TIMESTAMPTZ", typ, flags=re.I)
            dm = re.search(r"DEFAULT\s+(\S+)", rest, re.I)
            tcols[name] = dict(type=typ, notnull=bool(re.search(r"NOT NULL|PRIMARY KEY", rest, re.I)),
                               default=dm.group(1) if dm else "")
            if re.search(r"PRIMARY KEY", rest, re.I):
                cons.append(dict(kind="p", name=f"{t}_pkey", cols=(name,)))
            if re.search(r"\bUNIQUE\b", rest, re.I):
                cons.append(dict(kind="u", name=f"{t}_{name}_key", cols=(name,)))
            fm = re.search(r"REFERENCES\s+(\w+)\s*\((\w+)\)(?:\s+ON DELETE\s+(CASCADE|SET NULL|RESTRICT|NO ACTION))?", rest, re.I)
            if fm:
                cons.append(dict(kind="f", name=f"{t}_{name}_fkey", cols=(name,), ref=(fm.group(1), fm.group(2)),
                                 on_delete=(fm.group(3) or "NO ACTION").upper()))
        tables[t] = dict(cols=tcols, cons=cons)
    for m in re.finditer(r"CREATE INDEX\s+(\w+)\s+ON\s+(\w+)\s*\(([^)]*)\)", sql, re.I):
        indexes.append(dict(name=m.group(1), table=m.group(2), cols=tuple(x.strip() for x in m.group(3).split(","))))
    return files, tables, indexes

def norm_type(s):
    return re.sub(r"\s+", "", s.upper())

def rename_constraint_sql(t, old, new):
    return (f"DO $$ BEGIN\n    IF EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = '{t}'::regclass AND conname = '{old}') THEN\n"
            f"        ALTER TABLE {t} RENAME CONSTRAINT {old} TO {new};\n    END IF;\nEND $$;")

AUDIT_RENAMES = OrderedDict([("created_at", "created_date_time"), ("updated_at", "modified_date_time"), ("updated_by", "modified_by")])
RENAMED = []

def rename_column_sql(t, old, new):
    chk = lambda c: (f"SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() "
                     f"AND table_name = '{t}' AND column_name = '{c}'")
    return (f"DO $$ BEGIN\n    IF EXISTS ({chk(old)})\n       AND NOT EXISTS ({chk(new)}) THEN\n"
            f"        ALTER TABLE {t} RENAME COLUMN {old} TO {new};  -- audit standard (data preserved)\n    END IF;\nEND $$;")

def emit_v3(files, ex_tables, ex_indexes):
    out = [header(f"Flyway migration V3 — extends existing V1/V2 ({', '.join(files)}) and creates the rest",
                  "-- Existing (V1/V2) tables are ALTERed in place: guarded RENAME COLUMN created_at->created_date_time /\n"
                  "-- updated_at->modified_date_time (data preserved), ADD COLUMN IF NOT EXISTS, SET DEFAULT,\n"
                  "-- constraint/index renames to the v3 naming convention, CHECK constraints; all other tables are CREATEd.\n"
                  "-- No BEGIN/COMMIT here — Flyway wraps each migration in a transaction.\n"
                  "-- pgcrypto is NOT created here: gen_random_uuid() is built into PostgreSQL 13+.\n")]
    out.append("-- 0a. Thai timezone (session + database default)\n" + TZ_SESSION + TZ_DATABASE)
    out.append("-- 0b. modified_date_time trigger function (audit standard)\n" + TRIGGER_FN)
    existing_fk_ok = set()
    for t, ex in ex_tables.items():
        if t not in TABLES:
            warn(f"V1/V2 table {t} not in v3 design — left untouched"); continue
        tb = TABLES[t]
        out.append(f"-- ---------------------------------------------------------------------------\n-- {t} (existing from V1/V2 — ALTER)\n-- ---------------------------------------------------------------------------")
        # audit standard: rename legacy audit columns in place (data preserved), guarded so re-runs are safe
        ex = dict(ex); ex["cols"] = OrderedDict(ex["cols"])
        for old, new in AUDIT_RENAMES.items():
            if old in ex["cols"] and old not in tb["cols"] and new in tb["cols"] and new not in ex["cols"]:
                out.append(rename_column_sql(t, old, new))
                ex["cols"] = OrderedDict((new if k == old else k, v) for k, v in ex["cols"].items())
                RENAMED.append(f"{t}.{old} -> {new}")
        added = []
        # columns
        for c, cd in tb["cols"].items():
            if c not in ex["cols"]:
                if not cd["nullable"] and not cd["default"]:
                    warn(f"V3: new NOT NULL column {t}.{c} without default — fails if table has rows")
                d = f" DEFAULT {cd['default']}" if cd["default"] else ""
                nn = " NOT NULL" if not cd["nullable"] else ""
                out.append(f"ALTER TABLE {t} ADD COLUMN IF NOT EXISTS {c} {cd['type']}{d}{nn};")
                added.append(c)
                continue
            e = ex["cols"][c]
            if norm_type(e["type"]) != norm_type(cd["type"]):
                out.append(f"ALTER TABLE {t} ALTER COLUMN {c} TYPE {cd['type']};  -- was {e['type']}")
                warn(f"V3: type change {t}.{c} {e['type']} -> {cd['type']}")
            if cd["default"] and e["default"] != cd["default"]:
                out.append(f"ALTER TABLE {t} ALTER COLUMN {c} SET DEFAULT {cd['default']};")
            want_nn = (not cd["nullable"]) or cd["pk"]
            if want_nn and not e["notnull"]:
                out.append(f"ALTER TABLE {t} ALTER COLUMN {c} SET NOT NULL;")
                warn(f"V3: {t}.{c} SET NOT NULL — fails if existing NULLs")
            if not want_nn and e["notnull"]:
                out.append(f"ALTER TABLE {t} ALTER COLUMN {c} DROP NOT NULL;")
        for c in ex["cols"]:
            if c not in tb["cols"]:
                warn(f"V3: existing column {t}.{c} not in v3 design — kept")
        # backfill audit timestamps on existing rows (before the trigger exists): modified = created; created from a
        # pre-existing business timestamp when the table had no created_at (e.g. merchant_documents.uploaded_at)
        if "created_date_time" in added:
            src = next((x for x in ("uploaded_at", "granted_at", "occurred_at") if x in ex["cols"]), None)
            if src:
                out.append(f"UPDATE {t} SET created_date_time = {src};  -- audit backfill for existing rows")
        if "modified_date_time" in added:
            out.append(f"UPDATE {t} SET modified_date_time = created_date_time;  -- audit backfill: modified = created for existing rows")
        # constraints
        design_uq = {u[0]: u for u in tb["uniques"] if u[1] is None}
        have_uq = set()
        for con in ex["cons"]:
            if con["kind"] == "p":
                new = ident_name("pk", t, [])
                assert con["cols"] == tuple(tb["pk"]), (t, con)
                if con["name"] != new: out.append(rename_constraint_sql(t, con["name"], new))
            elif con["kind"] == "u":
                if con["cols"] in design_uq:
                    have_uq.add(con["cols"])
                    new = uq_name(t, con["cols"])
                    if con["name"] != new: out.append(rename_constraint_sql(t, con["name"], new))
                else:
                    out.append(f"ALTER TABLE {t} DROP CONSTRAINT IF EXISTS {con['name']};  -- v3 design: no UNIQUE({', '.join(con['cols'])})")
                    warn(f"V3: drops existing UNIQUE {t}({', '.join(con['cols'])}) [{con['name']}] — not in v3 design")
            elif con["kind"] == "f":
                fk = next((f for f in FKS if f["table"] == t and f["col"] == con["cols"][0]), None)
                if fk and fk["ref_table"] == con["ref"][0] and fk["on_delete"] == con["on_delete"]:
                    existing_fk_ok.add((t, con["cols"][0]))
                    if con["name"] != fk["name"]: out.append(rename_constraint_sql(t, con["name"], fk["name"]))
                else:
                    out.append(f"ALTER TABLE {t} DROP CONSTRAINT IF EXISTS {con['name']};  -- recreated with v3 rule in FK section")
        for cols_, (c_, where, src) in design_uq.items():
            if cols_ not in have_uq:
                out.append(f"ALTER TABLE {t} ADD CONSTRAINT {uq_name(t, cols_)} UNIQUE ({', '.join(cols_)});")
        for name, expr, src in tb["checks"]:
            if name in EXTRA_CHECKS:   # authz CHECK on an existing V1/V2 table: guarded for existing data
                out.append(f"""DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM {t} WHERE ({expr}) IS FALSE) THEN
        ALTER TABLE {t} ADD CONSTRAINT {name} CHECK ({expr}) NOT VALID;
        RAISE WARNING '{name}: existing rows violate the rule — constraint added NOT VALID (enforced for new/updated rows). Fix data, then: ALTER TABLE {t} VALIDATE CONSTRAINT {name};';
    ELSE
        ALTER TABLE {t} ADD CONSTRAINT {name} CHECK ({expr});
    END IF;
END $$;""")
            else:
                out.append(f"ALTER TABLE {t} ADD CONSTRAINT {name} CHECK ({expr});")
        for name, expr, where, src in tb["xuniques"]:   # authz partial unique on existing table: fail fast with remediation
            w = f" WHERE {where}" if where else ""
            out.append(f"""DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM {t}{w} GROUP BY {expr} HAVING count(*) > 1) THEN
        RAISE EXCEPTION '{name}: duplicate rows exist for ({expr}){w.replace("'", "''")} — resolve them (e.g. set older rows to a closed status) and re-run V3';
    END IF;
END $$;""")
        # indexes: rename V1/V2 indexes to v3 names
        design_idx = {i[0]: i for i in tb["final_idx"] if i[1] is None}
        for ix in [i for i in ex_indexes if i["table"] == t]:
            new = ix_name(t, ix["cols"])
            if ix["cols"] not in design_idx:
                warn(f"V3: existing index {ix['name']} on {t}({', '.join(ix['cols'])}) not in v3 design — kept, renamed {new}")
            if ix["name"] != new:
                out.append(f"ALTER INDEX IF EXISTS {ix['name']} RENAME TO {new};")
        out += emit_indexes(t, if_not_exists=True)
        out += emit_comments(t)
        out += emit_trigger(t, replace=True)
        out.append("")
    out.append("-- =============================================================================\n-- New tables (v3)\n-- =============================================================================")
    for mod in MODULE_ORDER:
        for t in module_tables(mod):
            if t in ex_tables: continue
            out.append(emit_table_block(t))
        x = emit_extra_triggers(mod)  # shops/shop_members are new in V3
        if x: out.append(x)
    out.append("-- =============================================================================\n-- Foreign keys (added after all tables — handles cycles)\n-- =============================================================================")
    for fk in FKS:
        if (fk["table"], fk["col"]) in existing_fk_ok:
            out.append(f"-- {fk['name']}: already exists from V1/V2 (renamed above, ON DELETE {fk['on_delete']})")
        else:
            out.append(emit_fk(fk))
    out.append("-- =============================================================================\n-- authz data steps (Flyway V3 only)\n-- =============================================================================")
    out.append(V3_POST_SQL)
    out.append(catalog_seed_sql())
    return "\n".join(out) + "\n"

# ----------------------------------------------------------------------------- write files
def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def main():
    crosscheck_xlsx()
    os.makedirs(os.path.join(OUT, "modules"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "flyway"), exist_ok=True)
    # remove stale module files
    for f in os.listdir(os.path.join(OUT, "modules")):
        if f.endswith(".sql"): os.remove(os.path.join(OUT, "modules", f))

    ext = "CREATE EXTENSION IF NOT EXISTS pgcrypto;  -- gen_random_uuid() is core since PG13; kept for older tooling/compat\n"
    # modules
    mod_files = []
    m00 = (header("Module 00 — timezone + extensions + shared trigger function") + TZ_SESSION + "\n" + TZ_DATABASE
           + "\nBEGIN;\n\n" + ext + "\n" + TRIGGER_FN + "\nCOMMIT;\n")
    write(os.path.join(OUT, "modules", "00_extensions_functions.sql"), m00); mod_files.append("00_extensions_functions.sql")
    for i, mod in enumerate(MODULE_ORDER, 1):
        ts = module_tables(mod)
        fn = f"{i:02d}_{MODULE_FILE[mod]}.sql"
        body = "\n".join(emit_table_block(t) for t in ts) + emit_extra_triggers(mod)
        write(os.path.join(OUT, "modules", fn),
              header(f"Module {i:02d} — {mod} ({len(ts)} tables: {', '.join(ts)})",
                     "-- Run after 00_extensions_functions.sql; foreign keys are in 99_foreign_keys.sql.\n")
              + "BEGIN;\n\n" + body + "\nCOMMIT;\n")
        mod_files.append(fn)
    fk_sql = "\n".join(emit_fk(fk) for fk in FKS)
    write(os.path.join(OUT, "modules", "99_foreign_keys.sql"),
          header(f"Module 99 — all {len(FKS)} foreign keys (run last)") + "BEGIN;\n\n" + fk_sql + "\n\nCOMMIT;\n")
    mod_files.append("99_foreign_keys.sql")

    # full
    full = [header(f"Clean install for an EMPTY database — {len(TABLES)} tables, {len(FKS)} foreign keys",
                   "-- Usage: psql -v ON_ERROR_STOP=1 -d <db> -f ecommerce_schema_v3_full.sql\n"),
            TZ_SESSION, TZ_DATABASE, "BEGIN;\n", ext, TRIGGER_FN]
    for mod in MODULE_ORDER:
        full.append(f"-- #############################################################################\n-- MODULE: {mod}\n-- #############################################################################\n")
        for t in module_tables(mod):
            full.append(emit_table_block(t))
        x = emit_extra_triggers(mod)
        if x: full.append(x)
    full.append(f"-- #############################################################################\n-- FOREIGN KEYS ({len(FKS)}) — added after all tables to handle cycles\n-- #############################################################################\n")
    full.append(fk_sql + "\n")
    full.append("COMMIT;\n")
    write(os.path.join(OUT, "ecommerce_schema_v3_full.sql"), "\n".join(full))

    # drop_all
    rev = list(TABLES.keys())[::-1]
    drop = header("DROP ALL — resets a DEV database (destroys data!)",
                  f"-- Drops the {len(TABLES)} v3 tables + set_modified_date_time() + check_shop_single_owner() (+ legacy set_updated_at() if present).\n"
                  "-- Does NOT drop flyway_schema_history or extensions; database timezone setting is kept.\n") + \
        "BEGIN;\n\n" + "\n".join(f"DROP TABLE IF EXISTS {t} CASCADE;" for t in rev) + \
        "\n\n" + "".join(f"DROP FUNCTION IF EXISTS {tx['function']}() CASCADE;  -- authz constraint trigger function\n" for tx in TRIGGERS_EXTRA) + "DROP FUNCTION IF EXISTS set_modified_date_time() CASCADE;\nDROP FUNCTION IF EXISTS set_updated_at() CASCADE;  -- legacy (pre audit-standard)\n\nCOMMIT;\n"
    write(os.path.join(OUT, "drop_all.sql"), drop)

    # seed
    seed = header("Reference data seed — ONLY values defined by the design docs (idempotent)",
                  "-- Pure SQL (pgAdmin / DBeaver / Flyway / psql). Business data (hub_categories, blog, shops ...) is NOT seeded:\n"
                  "-- the design defines no concrete values for them.\n") + """
-- 1) platform_settings: 'order.auto_complete_days' = 7
--    Source: ER_NOTES 'Order completion (v3)' + CHANGELOG_V3_TH.md (แนะนำ platform_settings order.auto_complete_days = 7)
--    authz: is_admin_editable = true (allowlist ของ PLATFORM_SETTING_UPDATE) + value_schema; setting_value เดิมไม่ถูกเขียนทับ
INSERT INTO platform_settings (setting_key, setting_value, is_admin_editable, value_schema, description)
VALUES ('order.auto_complete_days', '7'::jsonb, true, '{"type": "integer", "minimum": 1, "maximum": 30}'::jsonb,
        'จำนวนวันหลัง DELIVERED ที่ระบบปิดออเดอร์เป็น COMPLETED อัตโนมัติ')
ON CONFLICT (setting_key) DO UPDATE SET is_admin_editable = EXCLUDED.is_admin_editable, value_schema = EXCLUDED.value_schema,
    description = EXCLUDED.description
WHERE (platform_settings.is_admin_editable, platform_settings.value_schema, platform_settings.description)
      IS DISTINCT FROM (EXCLUDED.is_admin_editable, EXCLUDED.value_schema, EXCLUDED.description);

-- 2) platform_roles: PLATFORM_ADMIN (the only value in Enums_Status 'platform_role').
--    platform_roles.user_id is NOT NULL → needs an existing user. Optional: set email once in this session, then re-run:
--      SELECT set_config('app.admin_email', 'admin@example.com', false);
--    Without that setting, this step is skipped (no user is invented). Works in pgAdmin / DBeaver / psql.
DO $seed_admin$
DECLARE
  v_email   text := nullif(btrim(current_setting('app.admin_email', true)), '');
  v_user_id uuid;
BEGIN
  IF v_email IS NULL THEN
    RAISE NOTICE 'platform_roles: skipped (run SELECT set_config(''app.admin_email'', ''you@example.com'', false); then re-run this script)';
    RETURN;
  END IF;
  SELECT id INTO v_user_id FROM users WHERE email = v_email;
  IF v_user_id IS NULL THEN
    RAISE WARNING 'platform_roles: user % not found — nothing inserted', v_email;
    RETURN;
  END IF;
  INSERT INTO platform_roles (user_id, role, grant_reason)
  VALUES (v_user_id, 'PLATFORM_ADMIN', 'seed_reference_data.sql')
  ON CONFLICT (user_id) WHERE revoked_at IS NULL DO NOTHING;   -- partial unique uq_platform_roles_user_id_active
  RAISE NOTICE 'platform_roles: PLATFORM_ADMIN ensured for %', v_email;
END
$seed_admin$;

-- 3) """ + catalog_seed_sql()
    write(os.path.join(OUT, "seed_reference_data.sql"), seed)

    # flyway V3
    files, ex_tables, ex_indexes = parse_existing(EXISTING_FLYWAY_DIR)
    if files:
        v3 = emit_v3(files, ex_tables, ex_indexes)
        write(os.path.join(OUT, "flyway", "V3__ecommerce_schema_v3.sql"), v3)
        print(f"Flyway V3 generated against existing: {files} ({list(ex_tables)})")
    else:
        write(os.path.join(OUT, "flyway", "V1__ecommerce_schema_v3_baseline.sql"),
              "\n".join(full).replace("BEGIN;\n", "", 1).replace("COMMIT;\n", ""))
        warn("V1/V2 not available — produced V1__ecommerce_schema_v3_baseline.sql instead of V3")

    # report
    n_uq = sum(len(tb["uniques"]) for tb in TABLES.values())
    n_ck = sum(len(tb["checks"]) for tb in TABLES.values())
    n_ix = sum(len(tb["final_idx"]) for tb in TABLES.values())
    n_trg = sum(1 for tb in TABLES.values() if "modified_date_time" in tb["cols"])
    n_xuq = sum(len(tb["xuniques"]) for tb in TABLES.values()); n_uq += n_xuq
    lines = [f"tables={len(TABLES)} columns={len(cols)} fks={len(FKS)} uniques={n_uq} checks={n_ck} "
             f"indexes={n_ix} modified_date_time_triggers={n_trg} audit_tables={N_AUDIT_TABLES}",
             "", "## Enum CHECK mapping (table.column -> Enums_Status group)"]
    lines += [f"{t}.{c} -> {g}" for (t, c), (g, v) in ENUM_MAP.items()]
    lines += ["", "## Value lists in descriptions WITHOUT an Enums_Status group (no CHECK generated)"]
    lines += [f"{t}.{c}: {'|'.join(v)}" for t, c, v in DESC_ONLY_LISTS]
    lines += ["", "## Unique constraints"]
    lines += [f"{t}({', '.join(u[0])}){' WHERE ' + u[1] if u[1] else ''}  <- {u[2]}" for t, tb in TABLES.items() for u in tb["uniques"]]
    lines += [f"{t}: {n} ON ({e}){' WHERE ' + w if w else ''}  <- {src}" for t, tb in TABLES.items() for n, e, w, src in tb["xuniques"]]
    lines += ["", "## authz CHECKs (schema_meta.CONSTRAINTS_EXTRA)"] + [f"{x['table']}: {x['name']} CHECK ({x['expr']})" for x in CONSTRAINTS_EXTRA if x["kind"] == "check"]
    lines += ["", "## authz constraint triggers"] + [f"{t}: {n} -> {tx['function']}()" for tx in TRIGGERS_EXTRA for t, n, _ in tx["triggers"]]
    lines += ["", "## Non-FK / composite indexes"]
    lines += [f"{t}({', '.join(i[0])}){' WHERE ' + i[1] if i[1] else ''}  <- {i[2]}" for t, tb in TABLES.items() for i in tb["final_idx"] if i[2] != "FK"]
    lines += ["", "## Audit standard — Flyway V3 column renames on existing V1/V2 tables (guarded RENAME COLUMN)"] + RENAMED
    lines += ["", "## Warnings / diagnostics"] + WARN
    write(os.path.join(OUT, "GENERATOR_REPORT.txt"), "\n".join(lines) + "\n")
    print(lines[0])
    print("modules:", ", ".join(mod_files))
    print(f"{len(WARN)} diagnostics:")
    for w in WARN: print("  -", w)

if __name__ == "__main__":
    main()
